### What Helpdesk learned from the malware sample:

- The malware sample splits each file into 256-byte pieces and encrypts every piece on its own with AES in counter mode.
- The counter block is a 15-byte constant plus one final byte.
- That final byte is picked separately for each piece (it is not sequential), and the counter then advances as the piece is encrypted.


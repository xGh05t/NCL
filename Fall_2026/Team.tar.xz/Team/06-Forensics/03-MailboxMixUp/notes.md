## Job Description

Our internal mailbox system can only accept files that are sized 2534 bytes or smaller and uses a specialized protocol for ensuring that the relevant files are all placed in a folder together with a manifest detailing how to reconstruct the files. However, it would appear that there was a logic bug that caused the mailbox to begin placing all the incoming messages into the same folder for a single day and not produce the manifest. It's not a high traffic mailbox but the messages we get are critical. We need you to figure out which messages belong together. Here's what we know from reaching out to the senders via an alternate communication method.

1. There's an encrypted report in there chunked into 9 pieces along with a combined key and nonce file of size 96 bytes. Then there's a verification tag for that message of size 16. It was encrypted using AES-SIV with a 64 byte key, and 32 byte nonce.
2. There are two images that contain information for our analysts. One should still be recoverable but the other may be chunked too much.


# The Book (Hard) — memdump.mem (Win10 build 10240, captured 2023-10-31 05:09 UTC)

**Status: all 6 answers confirmed correct (100/100), 2026-10-08.**

## Answers
| Q | Answer |
|---|---|
| Q1 OS | Windows 10 (Pro, build 10240) |
| Q2 Computer name | DESKTOP-OT97GG3 |
| Q3 User | liber8hacker |
| Q4 File of interest | C:\Users\liber8hacker\Desktop\black_book.db |
| Q5 Real name of "cloud" | Gloria Hampton |
| Q6 Password | avatar2 |

## Gotcha: Volatility 3 picked the wrong kernel base
Auto-detect set kernel base to 0xf800aa609000, which is actually hal.dll, so pslist/hivelist/hashdump returned nothing.
The real ntoskrnl (same PDB 3C77A203...-1) is at 0xf800aa67a000. Fix:
  vol -f memdump.mem --save-config cfg.json windows.info
  # edit kernel.offset and kernel.layer_name.kernel_virtual_offset -> 0xf800aa67a000 (272681742606336)
  vol -f memdump.mem -c cfg2.json windows.registry.hashdump

## black_book.db (opened in DB Browser for SQLite, PID 3768)
Schema: book(id, first_name, last_name) ; aliases(id, alias). Joined on id.
SQLite file pages are not contiguous in RAM, so carved the 4K table-leaf pages directly:
| id | alias | name |
|---|---|---|
| 1 | grace | robert sturm |
| 2 | wasp | laura replogle |
| 3 | ace | delmar couch |
| 4 | tor(?) | troy enriquez |
| 5 | diablo | leslie mullis |
| 6 | liber8 | tom hess |
| 7 | alpha | steve scott |
| 8 | cloud | gloria hampton |
| 9 | indie | barbara walters |
| 10 | ?ody (partially overwritten) | johanna weiland |

## Hashes (hashes.txt)
liber8hacker:1001 NT 214a7d83f1c36a5f7071137d7c6e5ae6 -> avatar2 (rockyou, john --format=NT)
Administrator/Guest/DefaultAccount: blank (31d6cfe0...)

## Verification pass (2nd method for each answer)
- Q1: SOFTWARE\Microsoft\Windows NT\CurrentVersion -> ProductName "Windows 10 Pro", CurrentBuild 10240
- Q2: SYSTEM ComputerName\ComputerName and Tcpip\Parameters Hostname both = DESKTOP-OT97GG3
- Q3: Winlogon LastUsedUsername/DefaultUserName = liber8hacker; sessions plugin shows DESKTOP-OT97GG3/liber8hacker
- Q4: filescan -> \Users\liber8hacker\Desktop\black_book.db; DB Browser (PID 3768) window title shows the C:\ path
- Q5: dumpfiles pulled the real black_book.db from the file cache (black_book_recovered.db here);
      SQL `select * from book b join aliases a on a.id=b.id` -> id 8 cloud = gloria hampton. -journal has the same names.
- Q6: MD4(UTF-16LE("avatar2")) = 214a7d83f1c36a5f7071137d7c6e5ae6, an exact match to the SAM hash

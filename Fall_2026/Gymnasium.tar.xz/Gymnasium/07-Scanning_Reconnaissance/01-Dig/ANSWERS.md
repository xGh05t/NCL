# **Dig**

**Category:** Scanning & Reconnaissance (NCL Fall 2026 Gymnasium)  
**Difficulty:** Easy (75 points)  
**Author:** xG//05t  
**Date:** October 8, 2026

> **Note:** All queries were sent to the challenge resolver with `@resolver` (10.7.222.68) for the zone `fortaigan.net`.

# **Answers**

| Q | Points | Question | Answer |
|---|---|---|---|
| 1 | 5 | IPv4 address for fortaigan.net | `104.231.72.5` |
| 2 | 5 | Number of mail servers | `3` |
| 3 | 10 | Mail server with first priority | `maila2.fortaigan.net` |
| 4 | 5 | IPv4 address of the name server | `104.231.73.10` |
| 5 | 5 | Full name of the responsible person | `Leo Danza` |
| 6 | 10 | Text flag in the DNS records | `SKY-PZUV-5091` |
| 7 | 15 | Priority of the SIP service over TCP | `0` |
| 8 | 20 | IPv4 address of the SIP server | `104.231.74.3` |

# **Commands**

```
dig @resolver fortaigan.net A +short              # Q1
dig @resolver fortaigan.net MX                    # Q2, Q3
dig @resolver fortaigan.net NS +short             # Q4 -> ns1.fortaigan.net
dig @resolver ns1.fortaigan.net A +short          # Q4
dig @resolver fortaigan.net RP                    # Q5 -> admin.fortaigan.net admin.fortaigan.net
dig @resolver admin.fortaigan.net TXT             # Q5
dig @resolver fortaigan.net TXT                   # Q6
dig @resolver _sip._tcp.fortaigan.net SRV         # Q7 -> 0 5 5060 sipserver.fortaigan.net
dig @resolver sipserver.fortaigan.net A +short    # Q8
```

# **Key Records**

```
fortaigan.net.            3600   IN  A    104.231.72.5
fortaigan.net.            3600   IN  MX   5 maila1.fortaigan.net.
fortaigan.net.            3600   IN  MX   3 maila2.fortaigan.net.
fortaigan.net.            3600   IN  MX   10 maila0.fortaigan.net.
fortaigan.net.                   IN  NS   ns1.fortaigan.net.
ns1.fortaigan.net.               IN  A    104.231.73.10
fortaigan.net.            3600   IN  RP   admin.fortaigan.net. admin.fortaigan.net.
admin.fortaigan.net.      3600   IN  TXT  "\"Leo" "Danza\""
fortaigan.net.            3600   IN  TXT  "\"SKY-PZUV-5091\""
_sip._tcp.fortaigan.net.  86400  IN  SRV  0 5 5060 sipserver.fortaigan.net.
sipserver.fortaigan.net.         IN  A    104.231.74.3
```

# **Notes**

> **Q3:** MX preference is lowest number first. `maila2` (3) beats `maila1` (5) and `maila0` (10). The records are not returned in priority order.

> **Q5:** The `SOA` query returned no answer. The responsible person is published in an `RP` record instead. Its second field points to a `TXT` record holding the full name, split across two strings (`"Leo" "Danza"`).

> **Q7:** SRV record format is `priority weight port target`. Priority is `0`, weight `5`, port `5060`.

> **Q8:** Resolve the SRV target `sipserver.fortaigan.net` to its A record.

## Hash Notes

All passwords used in this challenge are 5 characters long. They do not use any numbers or special characters.

### Question 1 Hash
Character Set: Armenian

### Question 2 Hash:
Character Set: Hiragana

### Question 3 Hash:
Character Set: CJK — very specifically only the character set of CJK Unified Ideographs Extension D

- This charset was chosen to be reasonable to crack in time during the competition. You'd be able to become native-level fluent in reading, writing, and speaking Mandarin Chinese before you would exhaust the keyspace for the main CJK character set.

- If some of the characters in the CJK set appear as boxes in your browser, terminal, etc., you will want to install a font that supports CJK characters. Noto Sans CJK / Noto Serif CJK from Google Fonts or the Source Han Sans/Mono fonts are freely available. Note that you may need to restart your browser after installing them for them to render.

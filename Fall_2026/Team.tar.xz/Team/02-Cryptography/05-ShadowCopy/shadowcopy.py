#!/usr/bin/env python3
"""
Shadow Copy (NCL) - one-shot solver.

Flaw: Liber8tion encrypts each 256-byte piece with AES-CTR whose counter block is
15 constant bytes + 1 byte chosen per piece. Only 256 keystream blocks exist, so all
pieces reuse windows of one cyclic 4096-byte keystream S:
    C[i] = P[i] ^ S[(16*ctr + i) % 4096]

Solve (no key needed):
  1. align: two text pieces XORed at the same keystream offset are always < 0x80
     -> relative counter of every piece (union-find)
  2. recover S column-by-column with English log-probabilities + neighbour context
  3. decrypt, pull "part N of 2" halves out of the DR pack (incident_pack.zip),
     join them with '-', drop candidates containing a zero, and print a per-character
     confidence margin.

usage: python3 shadowcopy.py [recovered_dir] [fragment]
       defaults: ~/recovered  ~/backups/laptop_fragment.bin
"""
import os, sys, re, math
from collections import defaultdict

ENC = sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser('~/recovered')
FRAG = sys.argv[2] if len(sys.argv) > 2 else os.path.expanduser('~/backups/laptop_fragment.bin')
PIECE, BLK, NCTR = 256, 16, 256
KS = BLK * NCTR
MINOV = 48

# ---------- load ----------
files, pieces = {}, []
for fn in sorted(os.listdir(ENC)):
    d = open(os.path.join(ENC, fn), 'rb').read()
    files[fn] = d
    for k in range(0, len(d), PIECE):
        pieces.append((fn, k // PIECE, d[k:k + PIECE]))
frag = open(FRAG, 'rb').read() if os.path.exists(FRAG) else b''
N = len(pieces)
print(f"[1] {len(files)} files, {N} pieces")

# ---------- align ----------
HI = int.from_bytes(b'\x80' * 32, 'big')
parent, rel = list(range(N)), [0] * N
def find(x):
    path = []
    while parent[x] != x: path.append(x); x = parent[x]
    acc = 0
    for y in reversed(path):
        acc = (acc + rel[y]) % NCTR; rel[y] = acc; parent[y] = x
    return x
def offset(x): return rel[x] if find(x) != x else 0

for i in range(N):
    a = pieces[i][2]
    for j in range(i + 1, N):
        b = pieces[j][2]
        for d in range(-15, 16):
            o = d * BLK
            s, e = max(0, o), min(len(a), o + len(b))
            if e - s < MINOV: continue
            x = int.from_bytes(a[s:s + 32], 'big') ^ int.from_bytes(b[s - o:s - o + 32], 'big')
            if bin(x & HI).count('1') > 1: continue
            bad = sum(1 for k in range(s, e) if (a[k] ^ b[k - o]) & 0x80)
            if bad <= (e - s) // 16:
                ri, rj = find(i), find(j)
                if ri != rj:
                    oi, oj = offset(i), offset(j)
                    parent[rj] = ri; rel[rj] = (oi + d - oj) % NCTR
groups = defaultdict(list)
for i in range(N): groups[find(i)].append(i)
comps = sorted((g for g in groups.values() if len(g) > 1), key=len, reverse=True)
print(f"[2] aligned groups: {[len(c) for c in comps]}")

# ---------- language model ----------
EN = dict(zip(" etaoinshrdlcumwfgypbvkjxqz",
              [18.3,10.2,7.5,6.5,6.2,5.7,5.7,5.3,5.0,4.9,3.3,3.3,2.3,2.2,2.0,2.0,1.7,1.6,1.5,1.4,1.3,.8,.6,.15,.1,.08,.07]))
LP = [None] * 256
for c in range(32, 127):
    ch = chr(c)
    w = EN.get(ch) or (EN[ch.lower()] * .08 if ch.lower() in EN else .4 if ch.isdigit()
                       else .6 if ch in '.,-:_=' else .05 if ch in "()'\"/@#*!?;&%+[]" else .005)
    LP[c] = math.log(w / 100)
LP[10] = math.log(.015); LP[9] = LP[13] = math.log(.0005)
def colscore(col, k):
    s = 0.0
    for c in col:
        v = LP[c ^ k]
        if v is None: return -1e9
        s += v
    return s
def cls(c):
    return 'l' if 97 <= c <= 122 else 'U' if 65 <= c <= 90 else 'd' if 48 <= c <= 57 else \
           's' if c == 32 else 'n' if c == 10 else 'p'
PAIR = {('l','l'):3,('s','l'):3,('l','s'):3,('U','l'):2,('s','U'):2,('U','U'):1,('d','d'):2,('l','U'):-4,
        ('l','d'):-3,('d','l'):-3,('s','s'):-1,('p','l'):-1,('l','p'):1,('p','s'):2,('n','U'):2,('p','p'):-1}

# ---------- recover keystream per group ----------
def solve(comp, pos, cols, mem, votes):
    cand = {p: [k for k in range(256) if all(LP[c ^ k] is not None for c in col)] or list(range(256))
            for p, col in cols.items()}
    S = {}
    for p in cols:
        S[p] = max(cand[p], key=lambda k: colscore(cols[p], k) + 40 * votes[p].get(k, 0))
    def pt(i, k):
        b = pieces[i][2]
        return b[k] ^ S[(pos[i] * BLK + k) % KS] if 0 <= k < len(b) else None
    for _ in range(3):                                   # neighbour-aware refinement
        changed = 0
        for p in cols:
            if votes[p]: continue                        # pinned by known plaintext
            def sc(kk):
                t = colscore(cols[p], kk)
                for i, k in mem[p]:
                    c = pieces[i][2][k] ^ kk
                    a, b = pt(i, k - 1), pt(i, k + 1)
                    if a is not None: t += .7 * PAIR.get((cls(a), cls(c)), 0)
                    if b is not None: t += .7 * PAIR.get((cls(c), cls(b)), 0)
                return t
            best = max(cand[p], key=sc)
            if best != S[p]: S[p] = best; changed += 1
        if not changed: break
    return S

# known plaintext seen across the share (boilerplate repeated in almost every file)
CRIBS = [b"Reminder to follow up with the vendor about the renewal.\n",
         b"The migration is scheduled for next weekend.\n",
         b"Please review the attached numbers before Friday.\n",
         b"Onboarding docs still need a pass before the new hire starts.\n",
         b"Incident response sheet.\n", b"id,name,status\n",
         b"Reminder to follow up with the vendor about the renewal.\nThe migration is scheduled for next weekend.\nPlease review the attached numbers before Friday.\n"]
CRIBS += [l + b"\n" for l in frag.split(b"\n")[1:-1] if len(l) >= 20]   # whole lines of the old fragment
def extent(t, o, ph):
    L, win = 0, []
    for j, ch in enumerate(ph):
        if o + j >= len(t): break
        win.append(t[o + j] == ch); win = win[-8:]
        if len(win) == 8 and sum(win) < 5: break
        L = j + 1
    while L and t[o + L - 1] != ph[L - 1]: L -= 1
    if L < 14 or sum(t[o + j] == ph[j] for j in range(L)) < .7 * L: return 0
    return L

def find_cribs(dec, pos):
    votes = defaultdict(dict)
    byf = defaultdict(dict)
    for (f, n), t in dec.items(): byf[f][n] = t
    for f, ns in byf.items():
        n_tot = (len(files[f]) + PIECE - 1) // PIECE
        t = b''.join(ns.get(k, b'\x00' * len(files[f][k*PIECE:(k+1)*PIECE])) for k in range(n_tot))
        forced = {}
        starts = [0] + [m.end() for m in re.finditer(rb'\n', t)]
        for o in starts:
            for ph in CRIBS:
                L = extent(t, o, ph)
                for j in range(L): forced.setdefault(o + j, ph[j])
            for n in range(100):                         # CSV rows: n,item-nnn,status
                for stt in (b'open', b'closed', b'pending'):
                    row = b'%d,item-%03d,%s\n' % (n, n, stt)
                    if sum(a == b for a, b in zip(t[o:o + len(row)], row)) >= len(row) - 2:
                        for j, ch in enumerate(row): forced.setdefault(o + j, ch)
        for o, ch in forced.items():
            i = pidx.get((f, o // PIECE)); k = o % PIECE
            if i in pos and k < len(pieces[i][2]):
                p = (pos[i] * BLK + k) % KS; key = pieces[i][2][k] ^ ch
                votes[p][key] = votes[p].get(key, 0) + 1
    return votes

pidx = {(f, n): i for i, (f, n, _) in enumerate(pieces)}
state = []   # (members, pos, cols, mem, S)
ncrib = 0
for comp in comps:
    pos = {i: offset(i) for i in comp}
    cols, mem = defaultdict(list), defaultdict(list)
    for i in comp:
        for k, c in enumerate(pieces[i][2]):
            p = (pos[i] * BLK + k) % KS
            cols[p].append(c); mem[p].append((i, k))
    votes = defaultdict(dict)
    S = solve(comp, pos, cols, mem, votes)
    # pieces that decrypt with many non-text bytes (zip headers, compressed data) do not vote
    binp = {i for i in comp if sum(1 for k, c in enumerate(pieces[i][2])
            if LP[c ^ S[(pos[i] * BLK + k) % KS]] is None) > len(pieces[i][2]) // 12}
    tcols, tmem = defaultdict(list), defaultdict(list)
    for p in cols:
        for (i, k), c in zip(mem[p], cols[p]):
            if i not in binp: tcols[p].append(c); tmem[p].append((i, k))
        if not tcols[p]: tcols[p], tmem[p] = cols[p], mem[p]
    cols, mem = tcols, tmem
    for rnd in range(3):
        S = solve(comp, pos, cols, mem, votes)
        dec = {(pieces[i][0], pieces[i][1]): bytes(c ^ S[(pos[i]*BLK + k) % KS] for k, c in enumerate(pieces[i][2])) for i in comp}
        nv = find_cribs(dec, pos)
        if sum(len(v) for v in nv.values()) == sum(len(v) for v in votes.values()) and rnd: break
        votes = nv
    ncrib += sum(1 for v in votes.values() if v); nbin = len(binp)
    state.append((comp, pos, cols, mem, S, votes))
print(f"[3] keystream recovered ({ncrib} bytes pinned by known plaintext)")

# ---------- decrypt ----------
owner, plain = {}, {}
for st in state:
    comp, pos, cols, mem, S, votes = st
    for i in comp:
        owner[i] = st
        b = pieces[i][2]
        plain[(pieces[i][0], pieces[i][1])] = bytes(c ^ S[(pos[i] * BLK + k) % KS] for k, c in enumerate(b))
def text(f):
    d = files[f]
    return b''.join(plain.get((f, k), b'?' * len(d[k * PIECE:(k + 1) * PIECE]))
                    for k in range((len(d) + PIECE - 1) // PIECE))
os.makedirs('out', exist_ok=True)
for f in files: open(os.path.join('out', f + '.dec'), 'wb').write(text(f))
from collections import Counter
VOC = Counter()
for f in files:
    for w in re.findall(rb'[A-Za-z]{3,}', text(f)): VOC[w.lower()] += 1
for c in CRIBS:
    for w in re.findall(rb'[A-Za-z]{3,}', c): VOC[w.lower()] += 5
VOCAB = {w for w, n in VOC.items() if n >= 3}
def token_ok(buf, at):
    """is the alphabetic token covering buf[at] a known word? (non-letters count as ok if neighbours are sane)"""
    c = buf[at]
    if not (65 <= c <= 90 or 97 <= c <= 122):
        return None
    a = at
    while a > 0 and (65 <= buf[a-1] <= 90 or 97 <= buf[a-1] <= 122): a -= 1
    b = at
    while b + 1 < len(buf) and (65 <= buf[b+1] <= 90 or 97 <= buf[b+1] <= 122): b += 1
    w = bytes(buf[a:b+1]).lower()
    if len(w) < 3 or a == 0 or b == len(buf) - 1: return None
    return w in VOCAB
def show(b): return ''.join(chr(x) if 32 <= x < 127 else '.' for x in b)
def evidence(f, o, detail=False):
    """best alnum char at file offset o, margin to runner-up, #other pieces."""
    i = pidx[(f, o // PIECE)]
    if i not in owner: return '?', 0.0, 0
    comp, pos, cols, mem, S, votes = owner[i]
    k = o % PIECE; p = (pos[i] * BLK + k) % KS
    oth = [(j, kk) for j, kk in mem[p] if j != i]
    col = [pieces[j][2][kk] for j, kk in oth]
    cb = pieces[i][2][k]
    def sc(key):
        v = colscore(col, key)
        if v < -1e8: v = sum(LP[c ^ key] if LP[c ^ key] is not None else -25.0 for c in col)
        for j, kk in oth:                                # does it complete real words / sane context?
            b = pieces[j][2]; base = pos[j] * BLK; lo, hi = max(0, kk - 14), min(len(b), kk + 15)
            ctx = bytearray(b[x] ^ S[(base + x) % KS] for x in range(lo, hi)); ctx[kk - lo] = b[kk] ^ key
            ok = token_ok(ctx, kk - lo)
            if ok is True: v += 6
            elif ok is False: v -= 2
            c = ctx[kk - lo]
            if kk - lo > 0: v += .7 * PAIR.get((cls(ctx[kk-lo-1]), cls(c)), 0)
            if kk - lo + 1 < len(ctx): v += .7 * PAIR.get((cls(c), cls(ctx[kk-lo+1])), 0)
        return v + 40 * votes[p].get(key, 0)
    ranked = sorted(((sc(key), chr(cb ^ key), key) for key in range(256)
                     if chr(cb ^ key) in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), reverse=True)
    if detail:
        for v, ch, key in ranked[:2]:
            print(f"        if {ch!r}: other pieces read ->")
            for j, kk in oth:
                b = pieces[j][2]; base = pos[j] * BLK; lo, hi = max(0, kk - 8), min(len(b), kk + 9)
                ctx = bytearray(b[x] ^ S[(base + x) % KS] for x in range(lo, hi)); ctx[kk - lo] = b[kk] ^ key
                print(f"            {pieces[j][0][:26]:26} {show(ctx[:kk-lo])}[{show(ctx[kk-lo:kk-lo+1])}]{show(ctx[kk-lo+1:])}")
    return ranked[0][1], ranked[0][0] - ranked[1][0], len(oth)

# ---------- find the reference ----------
print("\n[4] every SKY- reference seen (decoys included):")
for f in files:
    for m in re.finditer(rb'S.Y-[A-Z0-9]{4}(?:-[A-Z0-9]{4})?', text(f)):
        print(f"      {f:34} {m.group().decode()}")

halves = {}
T1, T2 = b"part 1 of 2: SKY-", b"part 2 of 2, join with '-': "
packs = [f for f in files if f.endswith('.zip.enc')] or list(files)
bestpair = None
for f in packs:
    t = text(f)
    s1 = [sum(a == b for a, b in zip(t[o:o + len(T1)], T1)) for o in range(len(t))]
    s2 = [sum(a == b for a, b in zip(t[o:o + len(T2)], T2)) for o in range(len(t))]
    for o2 in range(len(t)):
        for o1 in range(0, max(0, o2 - 30)):             # part 1 comes before part 2
            sc = s1[o1] / len(T1) + s2[o2] / len(T2)
            if bestpair is None or sc > bestpair[0]:
                bestpair = (sc, f, o1, o2, s1[o1] / len(T1), s2[o2] / len(T2))
if bestpair:
    sc, f, o1, o2, q1, q2 = bestpair
    print(f"\n[5] located 'part 1 of 2' line ({q1:.0%} match) and 'part 2 of 2' line ({q2:.0%} match) in {f}")
    if min(q1, q2) < .6: print("[!] a 'part N of 2' line is badly garbled - treat the result as a lead and check out/*.dec")
    for h, o in (('1', o1 + len(T1)), ('2', o2 + len(T2))):
        halves[h] = (f, o, [evidence(f, o + j) for j in range(4)], sc)
print("    code chars as char(confidence margin, #pieces backing it); margin >= 8 is solid:")
for h in sorted(halves):
    f, o, ev, _ = halves[h]
    print(f"      part {h} in {f} @{o}: " + "  ".join(f"{c}({m:.0f},{n})" for c, m, n in ev))
if set(halves) >= {'1', '2'}:
    a = ''.join(c for c, _, _ in halves['1'][2]); b = ''.join(c for c, _, _ in halves['2'][2])
    flag = f"SKY-{a}-{b}"
    weak = [(h, j) for h in '12' for j, (c, m, _) in enumerate(halves[h][2]) if m < 8]
    print(f"\n[FLAG] {flag}")
    if '0' in flag: print("       WARNING: contains a zero - challenge says the real one has none")
    if not weak: print("       all 8 characters have a clear margin over the runner-up -> submit")
    for h, j in weak:
        f, o = halves[h][0], halves[h][1] + j
        print(f"\n     weak char: part {h} position {j} (file offset {o}) - pick the reading that is real text:")
        evidence(f, o, detail=True)
else:
    print("\n[!] 'part N of 2' halves not found - check out/incident_pack.zip.enc.dec manually")

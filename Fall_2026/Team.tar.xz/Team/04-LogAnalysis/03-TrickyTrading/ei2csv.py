#!/usr/bin/env python3
# Decode the EI binary logs (ZHDR/ZVAL format) into CSV files.
# Usage: python3 ei2csv.py <folder with the 5 log files> <output folder>
import os, sys, struct, uuid

def tok(s, k=0, stop=None):
    out = []
    while k < len(s) and s[k] != stop:
        if s[k] == ' ': k += 1; continue
        t, k = one(s, k); out.append(t)
    return out, k

def one(s, k):
    if s[k] == '?':
        t, k = one(s, k + 1); return ('?', t), k
    if s[k] == 'l':
        t, k = tok(s, k + 2, ')'); return ('l', t), k + 1
    return s[k], k + 1

def rd(t, b, o):
    if isinstance(t, tuple):
        if t[0] == '?':
            return rd(t[1], b, o + 1) if b[o] else (None, o + 1)
        n = struct.unpack('>I', b[o:o+4])[0]; o += 4; rows = []
        for _ in range(n):
            r = []
            for x in t[1]:
                v, o = rd(x, b, o); r.append(v)
            rows.append(r)
        return rows, o
    if t == 'u': return str(uuid.UUID(bytes=b[o:o+16])), o + 16
    if t in 'it': return struct.unpack('>q', b[o:o+8])[0], o + 8
    if t in 'se':
        n = struct.unpack('>H', b[o:o+2])[0]; return b[o+2:o+2+n].decode(), o + 2 + n
    if t == 'm':
        n = struct.unpack('>I', b[o:o+4])[0]; o += 4; d = {}
        for _ in range(n):
            d[str(uuid.UUID(bytes=b[o:o+16]))] = struct.unpack('>q', b[o+16:o+24])[0]; o += 24
        return d, o

def parse(path):
    b = open(path, 'rb').read()
    n = struct.unpack('>I', b[4:8])[0]; toks, _ = tok(b[8:8+n].decode()); o = 8 + n; recs = []
    while o < len(b):
        ln = struct.unpack('>I', b[o+4:o+8])[0]; o += 8; end = o + ln; r = []
        for t in toks:
            v, o = rd(t, b, o); r.append(v)
        assert o == end; recs.append(r)
    return recs

src, dst = sys.argv[1], sys.argv[2]
os.makedirs(dst, exist_ok=True)
f = {w: parse(os.path.join(src, x)) for x in os.listdir(src) for w in
     ['item_data.info', 'market_transactions.transactions', 'market_updates.transactions',
      'player_data.info', 'player_transactions.transactions'] if x.endswith(w)}
item = {r[5]: r[0] for r in f['item_data.info']}
user = {r[0]: r[1] for r in f['player_data.info']}

def w(name, header, rows):
    with open(os.path.join(dst, name), 'w') as fh:
        fh.write(header + '\n')
        for r in rows: fh.write(','.join('' if v is None else str(v) for v in r) + '\n')
    print('wrote', name)

w('items.csv', 'item_uuid,name,value,tier,class,slot',
  [[r[5], r[0], r[1], r[2], r[3], r[4]] for r in f['item_data.info']])
w('players.csv', 'player_uuid,username,level,xp,gold,class',
  [r[:6] for r in f['player_data.info']])
w('start_inventory.csv', 'username,item_uuid,item_name,qty',
  [[r[1], i, item[i], q] for r in f['player_data.info'] for i, q in r[8].items()])
w('market.csv', 'username,item_uuid,item_name,qty,unit_price,side,ts',
  [[user[r[0]], r[1], item[r[1]], r[2], r[3], r[4], r[5]] for r in f['market_transactions.transactions']])
w('player_tx.csv', 'username,xp,gold,ts',
  [[user[r[1]], r[2], r[3], r[6]] for r in f['player_transactions.transactions']])
w('market_updates.csv', 'ts,item_uuid,item_name,stock,price',
  [[r[1], i, item[i], s, p] for r in f['market_updates.transactions'] for i, s, p in r[0]])

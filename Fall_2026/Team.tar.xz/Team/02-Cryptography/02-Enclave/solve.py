import hmac, hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

iv  = bytes.fromhex("000c4add283d9db3da8c6427")
ct  = bytes.fromhex("21cde5988b9625cc5b140712a3")
tag = bytes.fromhex("2b7c2b0910af6f2d180c2574e6bb021e")
blob = ct + tag   # Python's AESGCM expects the tag appended to the ciphertext

for length in (5, 6, 7):
    for n in range(10**length):
        kc = str(n).zfill(length).encode()
        salt = kc[::-1].ljust(16, b"\0")                         # reversed keycode, zero-padded to 16
        prk = hmac.new(salt, kc, hashlib.sha256).digest()        # HKDF extract
        key = hmac.new(prk, b"\x01", hashlib.sha256).digest()    # HKDF expand: 32 bytes, empty info
        try:
            print(kc.decode(), AESGCM(key).decrypt(iv, blob, None).decode())
            raise SystemExit
        except InvalidTag:
            pass

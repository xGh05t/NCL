#!/usr/bin/env python3
"""Shadow Copy solver - AES-CTR with 1-byte per-piece counter => keystream reuse.

Model: counter block = 15-byte const || b, b chosen per 256-byte piece, then +1 per
16-byte block.  Only 256 keystream blocks exist, so the whole keystream is a cyclic
4096-byte stream S, and a piece starting at counter c has  C[i] = P[i] ^ S[(16c+i) % 4096].

Steps:
 1. split every file into 256-byte pieces
 2. align pieces against each other (XOR of two text ciphertexts at the same counter
    is always < 0x80)  -> relative counter of every piece (union-find)
 3. recover S per column by frequency analysis, then refine with the known fragment
 4. decrypt everything, write to out/, grep for SKY-
usage: python3 solve.py <encrypted_dir> [fragment_file] [--skip N] [--tail N]
"""
import os, sys, re
from collections import defaultdict

PIECE, BLK, NCTR = 256, 16, 256
KS = BLK * NCTR  # 4096
MINOV = 48

args = [a for a in sys.argv[1:]]
skip = tail = 0
if '--skip' in args:
    i = args.index('--skip'); skip = int(args[i + 1]); del args[i:i + 2]
if '--tail' in args:
    i = args.index('--tail'); tail = int(args[i + 1]); del args[i:i + 2]
encdir = args[0]
frag = open(args[1], 'rb').read() if len(args) > 1 else b''

# ---------- 1. load pieces ----------
files = {}
pieces = []  # (fname, piece_index, bytes)
for root, _, fns in os.walk(encdir):
    for fn in sorted(fns):
        p = os.path.join(root, fn)
        d = open(p, 'rb').read()
        d = d[skip:len(d) - tail if tail else None]
        rel = os.path.relpath(p, encdir)
        files[rel] = d
        for k in range(0, len(d), PIECE):
            pieces.append((rel, k // PIECE, d[k:k + PIECE]))
print(f"[+] {len(files)} files, {len(pieces)} pieces")

# ---------- 2. pairwise alignment ----------
HI = int.from_bytes(b'\x80' * 32, 'big')
def ok_xor(a, b, off):
    """piece b starts `off` bytes (multiple of 16) after piece a in keystream."""
    s0 = max(0, off); e0 = min(len(a), off + len(b))
    if e0 - s0 < MINOV: return 0, 0
    x = int.from_bytes(a[s0:s0+32], 'big') ^ int.from_bytes(b[s0-off:s0-off+32], 'big')
    if bin(x & HI).count('1') > 1: return 0, 0   # fast reject
    n = 0; bad = 0
    for i in range(max(0, off), min(len(a), off + len(b))):
        x = a[i] ^ b[i - off]
        n += 1
        if x & 0x80: bad += 1
    return n, bad

parent = list(range(len(pieces)))
rel = [0] * len(pieces)  # counter offset of piece relative to its root (mod 256)

def find(x):
    if parent[x] == x: return x, 0
    r, o = find(parent[x])
    parent[x] = r; rel[x] = (rel[x] + o) % NCTR
    return r, rel[x]

sys.setrecursionlimit(100000)
links = conflicts = 0
for i in range(len(pieces)):
    a = pieces[i][2]
    for j in range(i + 1, len(pieces)):
        b = pieces[j][2]
        for d in range(-15, 16):            # counter(j) - counter(i)
            n, bad = ok_xor(a, b, d * BLK)
            if n >= MINOV and bad <= n // 40:
                ri, oi = find(i); rj, oj = find(j)
                # ctr_j = ctr_i + d ; ctr_x = ctr_root + o_x
                if ri == rj:
                    if (oj - oi - d) % NCTR: conflicts += 1
                else:
                    parent[rj] = ri; rel[rj] = (oi + d - oj) % NCTR
                links += 1
print(f"[+] {links} overlap links, {conflicts} conflicts")

comps = defaultdict(list)
for i in range(len(pieces)):
    r, o = find(i); comps[r].append(i)
comps = sorted(comps.values(), key=len, reverse=True)
print("[+] component sizes:", [len(c) for c in comps[:10]])

# ---------- 3. keystream recovery per component ----------
import math
EN = {' ':18.3,'e':10.2,'t':7.5,'a':6.5,'o':6.2,'i':5.7,'n':5.7,'s':5.3,'r':5.0,'h':4.9,'l':3.3,
      'd':3.3,'u':2.3,'c':2.2,'m':2.0,'f':2.0,'w':1.7,'g':1.6,'p':1.5,'y':1.4,'b':1.3,'v':0.8,
      'k':0.6,'x':0.15,'j':0.1,'q':0.08,'z':0.07}
LP = {}
for c in range(256):
    ch = chr(c)
    if ch.lower() in EN and ch != ' ': w = EN[ch.lower()] * (1 if ch.islower() else 0.08)
    elif ch == ' ': w = EN[' ']
    elif ch.isdigit(): w = 0.25
    elif ch in '\n': w = 1.5
    elif ch in '.,-:': w = 0.6
    elif ch in "()'\"/@_=#*!?;&%+[]\t\r": w = 0.05
    elif 32 <= c < 127: w = 0.005
    else: w = None
    LP[c] = math.log(w / 100) if w else None
def printable(c): return LP[c] is not None

def score_col(col, k):
    s = 0.0
    for c in col:
        v = LP[c ^ k]
        if v is None: return -1e9
        s += v
    return s

results = []
for comp in comps:
    if len(comp) < 2: continue
    pos = {i: find(i)[1] for i in comp}            # counter of piece (relative)
    cols = defaultdict(list)                      # keystream byte index -> [(cipher byte, piece, i)]
    for i in comp:
        for k, c in enumerate(pieces[i][2]):
            cols[(pos[i] * BLK + k) % KS].append(c)
    S = {}
    for p, col in cols.items():
        best = max(range(256), key=lambda k: score_col(col, k))
        S[p] = best
    results.append((comp, pos, cols, S))

def decrypt_comp(comp, pos, S):
    out = {}
    for i in comp:
        f, pi, b = pieces[i]
        base = pos[i] * BLK
        out[(f, pi)] = bytes(c ^ S.get((base + k) % KS, c) for k, c in enumerate(b))
    return out

# ---------- 3a. context refinement (neighbour-aware scoring) ----------
def cls(c):
    if 97 <= c <= 122: return 'l'
    if 65 <= c <= 90: return 'U'
    if 48 <= c <= 57: return 'd'
    if c == 32: return 's'
    if c in (10, 13): return 'n'
    return 'p'
PAIR = {('l','l'):3,('s','l'):3,('l','s'):3,('U','l'):2,('s','U'):2,('U','U'):1,('d','d'):2,
        ('l','U'):-4,('l','d'):-3,('d','l'):-3,('s','s'):-1,('p','l'):-1,('l','p'):1,('p','s'):2,
        ('n','U'):2,('n','l'):0,('p','p'):-1,('U','d'):-1,('d','U'):-1}
def pscore(a, b): return PAIR.get((cls(a), cls(b)), 0)

for rnd in range(3):
    changed = 0
    for comp, pos, cols, S in results:
        members = defaultdict(list)   # keystream pos -> [(piece, offset)]
        for i in comp:
            for k in range(len(pieces[i][2])):
                members[(pos[i] * BLK + k) % KS].append((i, k))
        def pt(i, k):
            b = pieces[i][2]
            if not 0 <= k < len(b): return None
            kp = (pos[i] * BLK + k) % KS
            return b[k] ^ S[kp]
        for p, mem in members.items():
            def sc(kk):
                t = score_col(cols[p], kk)
                if t < -1e8: return t
                for i, k in mem:
                    c = pieces[i][2][k] ^ kk
                    a = pt(i, k - 1); b = pt(i, k + 1)
                    if a is not None: t += 0.7 * pscore(a, c)
                    if b is not None: t += 0.7 * pscore(c, b)
                return t
            best = max(range(256), key=sc)
            if best != S[p]: S[p] = best; changed += 1
    print(f"[+] refinement round {rnd+1}: {changed} keystream bytes changed")
    if not changed: break

# ---------- 3b. refine with known fragment (weighted vote, not override) ----------
FRAG_W = 1.5   # roughly one extra well-scored text byte
if frag:
    allS = []
    for comp, pos, cols, S in results:
        dec = decrypt_comp(comp, pos, S)
        for (f, pi), t in dec.items():
            for st in range(len(t)):
                seg = t[st:st + len(frag)]
                m = sum(1 for a, b in zip(seg, frag) if a == b)
                allS.append((m / max(len(seg), 1) if len(seg) >= 32 else 0, m, f, pi * PIECE + st))
    r, m, f, fo = max(allS)
    print(f"[+] fragment best match: {f} @ byte {fo}  ({m} chars, {r:.0%} of overlap)")
    if r > 0.5:
        for comp, pos, cols, S in results:
            idx = {(pieces[i][0], pieces[i][1]): i for i in comp}
            hints = {}
            for j, ch in enumerate(frag):
                off = fo + j
                i = idx.get((f, off // PIECE))
                if i is None or off % PIECE >= len(pieces[i][2]): continue
                hints[(pos[i] * BLK + off % PIECE) % KS] = pieces[i][2][off % PIECE] ^ ch
            for p, kh in hints.items():
                S[p] = max(range(256), key=lambda k: score_col(cols[p], k) + (FRAG_W if k == kh else 0))
            if hints: print(f"[+] fragment used as hint for {len(hints)} keystream bytes")

# ---------- 4. output ----------
os.makedirs('out', exist_ok=True)
plain = defaultdict(dict)
for comp, pos, cols, S in results:
    for k, v in decrypt_comp(comp, pos, S).items(): plain[k[0]][k[1]] = v
for f, d in files.items():
    n = (len(d) + PIECE - 1) // PIECE
    buf = b''.join(plain[f].get(i, b'?' * len(d[i*PIECE:(i+1)*PIECE])) for i in range(n))
    op = os.path.join('out', f.replace(os.sep, '_') + '.dec')
    open(op, 'wb').write(buf)
    for m in re.finditer(rb'(?i)S.Y-....-....|reference.{0,30}', buf):
        ctx = buf[max(0, m.start() - 60):m.end() + 20].replace(b'\n', b' | ')
        print(f"[!] {f}: {m.group().decode()}   ...{ctx.decode('latin1')}")
        pi_ = m.start() // PIECE
        for comp, pos, cols, S in results:
            for i in comp:
                if pieces[i][0] == f and pieces[i][1] == pi_:
                    dep = [len(cols[(pos[i]*BLK + o % PIECE) % KS]) - 1 for o in range(m.start(), m.end())]
                    print("    other pieces covering each char:", dep)
                    print("    top candidates per char (score drop vs best):")
                    for o in range(m.start(), m.end()):
                        kp = (pos[i]*BLK + o % PIECE) % KS
                        c = pieces[i][2][o % PIECE]
                        sc = sorted(((score_col(cols[kp], k), chr(c ^ k)) for k in range(256)
                                     if chr(c ^ k).isalnum() or chr(c ^ k) in ' -:'), reverse=True)[:4]
                        top = sc[0][0]
                        print(f"      [{o-m.start():2}] " + "  ".join(f"{ch!r}:{top-v:.1f}" for v, ch in sc))
print("[+] decrypted files in ./out/  (unaligned pieces shown as '?')")

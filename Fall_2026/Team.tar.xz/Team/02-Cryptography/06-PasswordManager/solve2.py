#!/usr/bin/env python3
"""Password Manager (Hard) - solver.
usage: python3 -I solve_simple.py ~/logs
"""
import sys, os, re, json, base64, hashlib
from cryptography.hazmat.primitives import serialization as S, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

D = os.path.expanduser(sys.argv[1] if len(sys.argv) > 1 else ".")
P = lambda f: os.path.join(D, f)
fp = lambda k: hashlib.sha256(k.public_key().public_bytes(
    S.Encoding.DER, S.PublicFormat.SubjectPublicKeyInfo)).hexdigest()

# 1. Find the tampered enrollment: audited key fp that is neither published nor a rotated-out old key
published = {v["fingerprint_sha256"] for v in json.load(open(P("org_directory.json"))).values()}
log = open(P("server.log")).read()
rotated_old = set(re.findall(r"action=key_rotated old_fp=([0-9a-f]{64})", log))
rogue_rec, rogue_fp = next((r, f) for r, f in
    re.findall(r"keydist\.audit - recovery_id=(\S+) org=\S+ pubkey_fp=([0-9a-f]{64})", log)
    if f not in published and f not in rotated_old)
user = re.search(rf"recovery_id={rogue_rec} user_id=(\S+)", log).group(1)
session = re.search(rf"recovery_id={rogue_rec} session_created=true session_id=(\S+)", log).group(1)

# 2. Rebuild carved keys: join fragments whose offset+length == next offset, keep the one matching the rogue fp
frags = {int(o, 16): (int(n), body) for o, n, body in re.findall(
    r"--- \S+ \(offset=(0x[0-9a-f]+) length=(\d+)\) ---\n(.*?)(?=\n--- |\Z)",
    open(P("workstation_recovered_keys.txt")).read(), re.S)}
privkey = None
for off, (n, body) in frags.items():
    if "BEGIN" not in body: continue
    if "END" not in body and off + n in frags: body += frags[off + n][1]
    b64 = re.search(r"BEGIN PRIVATE KEY-----(.*?)-----END", body, re.S)
    if not b64: continue
    try: k = S.load_der_private_key(base64.b64decode(re.sub(r"\s", "", b64.group(1))), None)
    except Exception: continue
    if fp(k) == rogue_fp: privkey = k

# 3. Unwrap the vault key (RSA-OAEP, SHA-256 + MGF1-SHA-256); ciphertexts are keyed by session_id
ct = bytes.fromhex(json.load(open(P("recovery_ciphertexts.json")))[session])
vault_key = privkey.decrypt(ct, padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),
                                             algorithm=hashes.SHA256(), label=None))

# 4. Open the vault (AES-256-GCM, AAD = user_id)
man = json.load(open(P("vault_manifest.json")))
vault = json.loads(AESGCM(vault_key).decrypt(bytes.fromhex(man["nonce"]),
                   open(P(man["vault_file"]), "rb").read(), user.encode()))

# 5. Item URLs are a second AES-GCM layer under the same vault key
admin = next(i for i in vault["items"].values() if i["name"] == "Internal Admin Portal")
inner = json.loads(AESGCM(vault_key).decrypt(bytes.fromhex(admin["url_nonce"]),
                   bytes.fromhex(admin["url"]), None))

print(f"rogue enrollment : {rogue_rec} fp={rogue_fp} session={session}")
print(f"Q1 user_id       : {user}")
print(f"Q2 vault key     : {vault_key.hex()}")
print(f"Q3 AWS secret    : {vault['credentials']['aws']['secret_key']}")
print(f"Q4 backup pass   : {inner['backup_password']}")

# **Decoding 8**

Room: NCL Fall 2026 Practice Game, Cryptography, Decoding 8 (Hard, 80 points)

Author: `xG//05t`  
Date: October 14, 2026

> **Educational purpose:** This document records work against a sanctioned NCL Fall 2026 practice challenge for training and after action review.

> **Prompt:** We have recovered an encrypted message. Our techs have no clue how to decode it. We need your help to decode it. Q1: What is the plaintext of the encrypted message?

# **Summary**

The challenge file `encrypted.txt` holds 147 space separated uppercase letters. It is not a cipher. The letters are filler, and the flag is stored in the letter frequency counts: the count of each letter `A` through `Z` is a single hex digit (0 to 15), and the 26 digits read in alphabet order decode as ASCII to the flag. Every classical cipher solver fails on this file because there is no English plaintext under it.

| Item | Value |
|------|-------|
| Q1 flag | `SKY-OXXP-1836` |
| Encoding | Letter counts A to Z as hex nibbles, hex to ASCII |
| Tools | `python3`, coreutils |
| Hints used | 5 point "Starting Point", 5 point "Website", 10 point "Pattern" |

# **Attack Chain**

```
triage                                -> 147 letters A-Z, every letter present except P
IC / Kasiski / period tests           -> IC 0.0497, no period, no repeated trigrams
classical solver sweep                -> Caesar, Affine, substitution, Vigenere family, autokey,
                                         Hill, Bifid, Phillips, Fractionated Morse, Enigma, Typex,
                                         transposition + Vigenere: all negative
hint 1 "Starting Point"               -> run a frequency analysis
hint 2 "Website"                      -> richkni.co.uk crypta freq.php
hint 3 "Pattern"                      -> counts range 0 to 15 -> hex nibbles
counts A..Z -> hex -> ASCII           -> SKY-OXXP-1836
```

# **1. Triage**

```
cat encrypted.txt
wc -c encrypted.txt
sha256sum encrypted.txt
```

```
D L S V R J V O X D N E E Y U K N N D Z D Q L R G L S R H J O H A I D A J M G M X W F R V B V L J Y D L H B F E F U F F C C Z J K M C H N J A J V Z X L H N V S T M N J Z O E H N H F R F N D D J L D R R H R Y R F J H J V D F H E I I J R H Z Q A K O U R R C H M J I O K J A V D L K Z B J R W H W
294 encrypted.txt
3ced3178ff0cfbeaae61d4fed4a739c26531e4efb228fd2f71441fd08b5de5ee  encrypted.txt
```

294 bytes is 147 letters, 146 spaces and a trailing newline. No lowercase, digits or punctuation.

# **2. Statistics**

```
python3 -c "
from collections import Counter
c = open('encrypted.txt').read().replace(' ','').strip()
C = Counter(c)
print(len(c), sorted(C.items(), key=lambda x: -x[1]))
print(sum(v*(v-1) for v in C.values()) / (len(c)*(len(c)-1)))
"
```

```
147 [('J', 15), ('R', 13), ('H', 13), ('D', 11), ('F', 9), ('L', 8), ('V', 8), ('N', 8), ('Z', 6), ('O', 5), ('E', 5), ('K', 5), ('A', 5), ('M', 5), ('I', 4), ('C', 4), ('S', 3), ('X', 3), ('Y', 3), ('U', 3), ('W', 3), ('B', 3), ('Q', 2), ('G', 2), ('T', 1)]
0.04966918274158979
```

The index of coincidence of 0.0497 sits between English (0.066) and random (0.0385). That reads like a polyalphabetic cipher, so the first pass went after one. Column IC showed no period from 1 to 73, and there are no repeated trigrams or quadgrams for Kasiski.

# **3. Classical solver sweep (all negative)**

Every candidate below was run with quadgram scoring and simulated annealing or exhaustive key search. The Bifid solver was validated by encrypting a known 147 letter test message and recovering it before trusting the negative result on the challenge text.

1. Caesar, Atbash, Affine, monoalphabetic substitution (16 annealing restarts)
2. Vigenere, Beaufort and Variant Beaufort, key lengths 1 to 60, plus a 113k word dictionary attack
3. Plaintext and ciphertext autokey, primers 1 to 25
4. Gronsfeld with digits of pi, e, sqrt 2 and phi; progressive (Trithemius) keys
5. Hill 3x3
6. Bifid with a 25 letter square, periods 0 to 70; conjugated matrix Bifid
7. Phillips, Fractionated Morse
8. Enigma rotors I to VIII, reflectors B and C, all positions, partial plugboard hill climb; CyberChef `Typex`
9. Columnar, Caesar box and rail fence transpositions combined with Vigenere
10. dCode Cipher Identifier and dCode automatic Vigenere solver

None produced English. That was the correct outcome: there was no English to find.

# **4. Hints**

Hint 1 (5 points), "Starting Point": `Try conducting a frequency analysis on the message`

Hint 2 (5 points), "Website": `https://www.richkni.co.uk/php/crypta/freq.php`

The site is a basic frequency analysis page with Caesar, Affine, Vigenere, transposition and ADFGVX helpers. Hints 1 and 2 point at the same thing: the letter counts.

Hint 3 (10 points), "Pattern": `That's odd how the quantities of the letters range between 0 and 15...`

0 to 15 is exactly the range of one hex digit.

# **5. Decode (Q1)**

Count each letter in alphabet order and write each count as one hex digit:

| Letter | A | B | C | D | E | F | G | H | I | J | K | L | M | N | O | P | Q | R | S | T | U | V | W | X | Y | Z |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Count | 5 | 3 | 4 | 11 | 5 | 9 | 2 | 13 | 4 | 15 | 5 | 8 | 5 | 8 | 5 | 0 | 2 | 13 | 3 | 1 | 3 | 8 | 3 | 3 | 3 | 6 |
| Hex | 5 | 3 | 4 | B | 5 | 9 | 2 | D | 4 | F | 5 | 8 | 5 | 8 | 5 | 0 | 2 | D | 3 | 1 | 3 | 8 | 3 | 3 | 3 | 6 |

Pair the nibbles and convert to ASCII:

```
53 4B 59 2D 4F 58 58 50 2D 31 38 33 36
S  K  Y  -  O  X  X  P  -  1  8  3  6
```

One liner:

```
python3 -c "
from collections import Counter
c = Counter(open('encrypted.txt').read())
h = ''.join('%X' % c[chr(65+i)] for i in range(26))
print(h, bytes.fromhex(h).decode())
"
```

```
534B592D4F5858502D31383336 SKY-OXXP-1836
```

The count was cross checked three ways (`python3`, `tr | wc`, `sort | uniq -c`) with identical results.

**Q1 answer: `SKY-OXXP-1836`.**

> **Note:** The second block is the letter `O` (`0x4F`), not the digit zero (`0x30`).

> **Note:** For future decoding problems, when a ciphertext defeats every solver and its statistics look slightly wrong, treat the statistics as the payload. Signs here were a maximum letter count of 15, exactly 26 counts available for 13 bytes, and one letter (`P`) with a count of zero, which supplied the `0` in `0x50`. Check counts as hex nibbles, counts as decimal ASCII, and counts in frequency order before running heavy cryptanalysis.

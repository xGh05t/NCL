# WiFi PCAP 2 (Medium) — Answers & Evidence

All answers confirmed correct on submission.

| Q | Answer | Evidence |
|---|--------|----------|
| Q1 – Number of IVs | **24592** | `aircrack-ng` reports `got 24592 IVs`; tshark: 25000 IV fields, 24592 unique |
| Q2 – Key size (bits) | **128** | WEP-128 = 104-bit secret key + 24-bit IV (cracked key is 13 bytes) |
| Q3 – IV of first packet | **0994ff** | Frame 1 raw bytes at offset 0x1A: `09 94 ff`, then key index `00` |
| Q4 – WEP key | **DE:AD:10:CC:D1:5E:A5:EC:DC:C2:D6:7A:CA** | `aircrack-ng` KEY FOUND, "Decrypted correctly: 100%"; airdecap-ng decrypted 24601 WEP packets, 0 corrupted |
| Q5 – TCP checksum of first packet | **08f0** | Decrypted frame 1 (192.168.0.100:57193 → 192.168.0.102:22, SSH): `Checksum: 0x08f0 [correct]` |

## Capture facts
- 25000 frames: 12 × 0x0020 Data + 24988 × 0x0028 QoS Data, all WEP-encrypted
- BSSID `C0:4A:00:80:76:E4`, no ESSID broadcast (same AP as PCAP 1)
- 4 stations seen

## Commands
```
aircrack-ng PCAP2.cap                                          # Q1, Q4 (PTW attack)
tshark -r PCAP2.cap -Y wlan.wep.iv -T fields -e wlan.wep.iv | sort -u | wc -l    # 24592
tshark -r PCAP2.cap -c1 -x                                     # Q3 raw bytes
airdecap-ng -w DE:AD:10:CC:D1:5E:A5:EC:DC:C2:D6:7A:CA -o decrypted.pcap PCAP2.cap
tshark -r decrypted.pcap -c1 -o tcp.check_checksum:TRUE -V | grep -i checksum    # Q5
```

## Cross-check (Q4/Q5)
tshark built-in decryption of the original capture with key `DEAD10CCD15EA5ECDCC2D67ACA` → frame 1 TCP checksum `0x08f0`; airdecap-ng output recalculates `0x08f0` as Good — both methods agree.

## Lesson
Same pattern as PCAP 1: count *unique* IVs (aircrack-ng's number), and give WEP key size as WEP-64/128 (IV included). A 13-byte key = WEP-128.

import crypto from "node:crypto";

function validate_keycode(keycode) {
  const validKeyRe = new RegExp("^[0-9]{5,7}$")
  return validKeyRe.test(keycode)
}

function generate_salt(keycode) {
  const verlan = keycode.split("").reverse().join("")
  return Buffer.concat([Buffer.from(verlan, "utf8")], 16)
}

function generate_secure_key(keycode) {
  if (validate_keycode(keycode)) {
    const salt = generate_salt(keycode)
    const key = crypto.hkdfSync('sha256', keycode, salt, '', 32)
    return key
  } else {
    throw new Error("Invalid keycode provided. Keycode must be numeric only between 5 and 7 characters.")
  }
}


function encrypt_data(data, key) {
  const IV = crypto.randomBytes(12)
  const cipher = crypto.createCipheriv("aes-256-gcm", key, IV)
  const ciphertext = Buffer.concat([cipher.update(data, "utf8"), cipher.final()]);
  return {
    iv: IV.toString("hex"),
    data: ciphertext.toString("hex"),
    tag: cipher.getAuthTag().toString("hex")
  }
}

const key = generate_secure_key(keycode)
const encrypted_payload  = encrypt_data(data, key)

export { encrypted_payload }


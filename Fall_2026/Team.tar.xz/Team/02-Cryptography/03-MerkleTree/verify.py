#!/usr/bin/env python3
# Usage: python3 verify.py <leaf_index> <proposed_hash>

import hashlib, json, sys

def hash_data(s):
    return hashlib.sha256(s.encode()).hexdigest()

def compute_root(leaf_hash, leaf_index, path):
    h, idx = leaf_hash, leaf_index
    for sibling in path:
        h = hash_data(h + sibling) if idx % 2 == 0 else hash_data(sibling + h)
        idx //= 2
    return h

if len(sys.argv) != 3:
    print(f"Usage: {sys.argv[0]} <leaf_index> <proposed_hash>")
    sys.exit(1)

leaf_index = int(sys.argv[1])
proposed   = sys.argv[2]

tree   = json.load(open("corrupted-tree.json"))
paths  = json.load(open("audit_paths.json"))
entry  = next(e for e in paths if e["leaf_index"] == leaf_index)

valid = compute_root(proposed, leaf_index, entry["path"]) == tree["expected_root"]
print(f"Valid: {valid}")

# SKY Log File v1 Specification

## Overview

The SKY log file format records network traffic data as raw binary data, reducing storage requirements compared with traditional text-based log files.

All multibyte numeric fields are stored in **big-endian** byte order. Fields are written consecutively with **no padding** unless stated otherwise.

## Terminology

| Term | Width | Size |
| --- | ---: | ---: |
| `int` | 32 bits | 4 bytes |
| `long` | 64 bits | 8 bytes |
| `timestamp` | 32-bit Unix timestamp | 4 bytes |

> The `long` type is defined by the format terminology but is not used by any SKY v1 field described in this specification.

## File Layout

A SKY v1 file contains one header followed immediately by zero or more fixed-size body records:

```text
+------------------+
| Header           |  Variable length
+------------------+
| Body record 0    |  16 bytes
+------------------+
| Body record 1    |  16 bytes
+------------------+
| ...              |
+------------------+
| Body record N-1  |  16 bytes
+------------------+
```

Let:

- `H` be the hostname length in bytes.
- `F` be the flag length in bytes.
- `N` be the number of body entries.

Then:

- Header size: `25 + H + F` bytes.
- Body size: `16N` bytes.
- Total file size: `25 + H + F + 16N` bytes.
- First body record offset: `25 + H + F`.

All offsets in this document are zero-based byte offsets from the beginning of the file.

## Header

The header begins at byte offset `0`. Its fields appear in the following order, with no padding:

| Order | Field | Size | Start offset |
| ---: | --- | ---: | ---: |
| 1 | Magic bytes | 8 bytes | `0` |
| 2 | Version number | 1 byte | `8` |
| 3 | Creation timestamp | 4 bytes | `9` |
| 4 | Hostname length | 4 bytes | `13` |
| 5 | Hostname | `H` bytes | `17` |
| 6 | Flag length | 4 bytes | `17 + H` |
| 7 | Flag | `F` bytes | `21 + H` |
| 8 | Number of entries | 4 bytes | `21 + H + F` |

The byte immediately following the header is at offset `25 + H + F`.

### Magic Bytes

- **Size:** 8 bytes
- **Offset:** `0`
- **Required value:** `0x91534B590D0A1A0A`

The magic bytes uniquely identify the file as using the SKY format. Every valid SKY file must begin with this exact eight-byte sequence.

### Version Number

- **Size:** 1 byte
- **Offset:** `8`
- **Required value for SKY v1:** `0x01`

This specification defines version 1 of the format. Every valid SKY v1 file must set this field to `0x01`.

### Creation Timestamp

- **Size:** 4 bytes
- **Offset:** `9`
- **Type:** `timestamp`

The creation timestamp denotes the start of data collection for the log file.

### Hostname Length

- **Size:** 4 bytes
- **Offset:** `13`
- **Type:** `int`

This field contains the hostname's length in bytes and determines how many bytes are read for the following **Hostname** field.

If no hostname is specified, the value is zero. Because this is a four-byte `int`, zero is encoded as `0x00000000` (equivalent in value to `0x00`).

### Hostname

- **Size:** `H` bytes
- **Offset:** `17`
- **Type:** Variable-length string

The hostname identifies the host on which the log file was created. Its byte length is the value of the preceding **Hostname Length** field.

SKY v1 does not specify a character encoding for this string. A writer and parser must therefore agree on the encoding independently.

### Flag Length

- **Size:** 4 bytes
- **Offset:** `17 + H`
- **Type:** `int`

This field contains the flag's length in bytes and determines how many bytes are read for the following **Flag** field.

If no flag is specified, the value is zero. Because this is a four-byte `int`, zero is encoded as `0x00000000` (equivalent in value to `0x00`).

### Flag

- **Size:** `F` bytes
- **Offset:** `21 + H`
- **Type:** Variable-length string or byte sequence

The flag stores a flag value for the log file. Its byte length is the value of the preceding **Flag Length** field.

This field may contain an encoded or encrypted flag, or a plaintext flag. The parsing application is responsible for interpreting the value and performing any necessary conversions. SKY v1 does not define a character encoding, encryption scheme, or encoding scheme for this field.

### Number of Entries

- **Size:** 4 bytes
- **Offset:** `21 + H + F`
- **Type:** `int`

This field specifies the number of records in the body.

## Body

The body begins at offset `25 + H + F` and contains exactly `N` records, where `N` is the value of the header's **Number of Entries** field.

Records are written in chronological order, with no padding between records. Every record contains four required fields and occupies exactly **16 bytes**.

### Record Layout

For a zero-based record index `i`, the record starts at:

```text
record_offset(i) = 25 + H + F + (16 * i)
```

The fields within each record are:

| Order | Field | Size | Type | Offset within record | Absolute start offset for record `i` |
| ---: | --- | ---: | --- | ---: | ---: |
| 1 | Source IP | 4 bytes | `int` | `0` | `25 + H + F + 16i` |
| 2 | Destination IP | 4 bytes | `int` | `4` | `29 + H + F + 16i` |
| 3 | Timestamp | 4 bytes | `timestamp` | `8` | `33 + H + F + 16i` |
| 4 | Bytes transferred | 4 bytes | `int` | `12` | `37 + H + F + 16i` |

### Source IP

The sender's IPv4 address, represented as a four-byte `int`.

### Destination IP

The destination's IPv4 address, represented as a four-byte `int`.

### Timestamp

The time at which the data stream was initiated, represented as a four-byte `timestamp`.

### Bytes Transferred

The number of bytes transferred in the data stream, represented as a four-byte `int`.

## Parsing Summary

1. Verify that bytes `0` through `7` equal `0x91534B590D0A1A0A`.
2. Verify that the version byte at offset `8` equals `0x01`.
3. Read all multibyte numeric values in big-endian byte order.
4. Read the creation timestamp.
5. Read `H`, then read exactly `H` bytes as the hostname.
6. Read `F`, then read exactly `F` bytes as the flag.
7. Read `N`, then read exactly `N` consecutive 16-byte body records.

The expected end-of-file offset after parsing all records is:

```text
25 + H + F + (16 * N)
```



#!/usr/bin/env python3
"""
Intercept (Hard) - LiberStream v2.1 solver
Usage:  python3 intercept_solve.py output.bin

Cipher: Alternating Step Generator (3 LFSRs)
  R0 = x^17 + x^3 + 1               (selector, clocks every step)
  R1 = x^19 + x^5 + x^2 + x + 1     (clocks when R0 bit = 1)
  R2 = x^23 + x^5 + 1               (clocks when R0 bit = 0)
  keystream bit = R1_out XOR R2_out, packed MSB-first into bytes

Attack:
  1. STATUS bodies are PKCS#7 padded -> bytes[plen:32] = (32-plen) -> known keystream.
  2. Per frame: brute force R0 (2^17); each guess fixes the clocking, so the keystream
     is LINEAR in R1+R2's 42 bits -> Gaussian elimination; the right guess is consistent.
  3. Init is linear (affine in seq): recover a few STATUS frames' states, combine them over
     GF(2) to predict the SECURE frame's state, decrypt.
"""
import sys

# ---------- LFSR sequences (abstract: any output bit of an LFSR obeys its recurrence) ----------
def lfsr_seq(init, L, E, n):
    s = [(init >> i) & 1 for i in range(L)]
    while len(s) < n:
        v = 0
        for e in E:
            v ^= s[len(s) - L + e]
        s.append(v)
    return s

R0 = (17, [0, 3])
R1 = (19, [0, 1, 2, 5])
R2 = (23, [0, 5])
NBITS = 256  # 32-byte body

def masks(L, E, n, shift):
    """symbolic sequence: element i = bitmask of which initial bits it depends on"""
    m = [1 << (i + shift) for i in range(L)]
    while len(m) < n:
        v = 0
        for e in E:
            v ^= m[len(m) - L + e]
        m.append(v)
    return m

A = masks(*R1, NBITS + 2, 0)    # R1 unknowns -> bits 0..18
B = masks(*R2, NBITS + 2, 19)   # R2 unknowns -> bits 19..41

# R0 is maximal length: every nonzero 17-bit start = an offset into one long sequence
PERIOD = (1 << 17) - 1
BIG = lfsr_seq(1, *R0, PERIOD + NBITS + 20)

def keystream(r0_off, x):
    c = BIG[r0_off:r0_off + NBITS]
    a = lfsr_seq(x & 0x7FFFF, *R1, NBITS + 2)
    b = lfsr_seq(x >> 19, *R2, NBITS + 2)
    n1 = n2 = 0
    out = []
    for t in range(NBITS):
        if c[t]: n1 += 1          # clock first ...
        else:    n2 += 1
        out.append(a[n1] ^ b[n2])  # ... then output
    return bytes(int("".join(map(str, out[i:i + 8])), 2) for i in range(0, NBITS, 8))

# ---------- frame parsing ----------
def load(path):
    d = open(path, "rb").read()
    mark = b"--- BEGIN BINARY STREAM ---\n"
    s = d[d.find(mark) + len(mark):]
    frames = []
    for p in range(0, len(s) - 39, 40):
        assert s[p:p + 2] == b"L8", f"desync at {p}"
        frames.append(dict(type=s[p + 2], seq=int.from_bytes(s[p + 3:p + 7], "big"),
                           plen=s[p + 7], body=s[p + 8:p + 40]))
    return frames

# ---------- per-frame state recovery ----------
def recover(frame):
    pl, body = frame["plen"], frame["body"]
    pad = 32 - pl
    known = {}  # bit position -> keystream bit
    for i in range(pl, 32):
        k = body[i] ^ pad
        for j in range(8):
            known[i * 8 + j] = (k >> (7 - j)) & 1
    first = min(known)
    hits = []
    for off in range(PERIOD):
        c = BIG[off:off + NBITS]
        piv = {}   # pivot bit -> (mask, rhs)
        n1 = n2 = 0
        ok = True
        for t in range(NBITS):
            if c[t]: n1 += 1
            else:    n2 += 1
            if t < first:
                continue
            m, r = A[n1] ^ B[n2], known[t]
            while m:
                p = m.bit_length() - 1
                if p in piv:
                    pm, pr = piv[p]; m ^= pm; r ^= pr
                else:
                    piv[p] = (m, r); break
            if not m and r:
                ok = False; break
        if ok and len(piv) == 42:
            x = 0
            for p in sorted(piv):               # back-substitute low -> high
                pm, pr = piv[p]
                v = pr ^ (bin(pm & ~(1 << p) & x).count("1") & 1)
                x |= v << p
            hits.append((off, x))
    assert len(hits) == 1, f"seq {frame['seq']}: {len(hits)} candidates"
    return hits[0]

# state as one 59-bit vector: R0 window | R1 | R2 (all linear in the post-init state)
def r0_window(off):
    return sum(BIG[off + i] << i for i in range(17))

OFF_OF = {}
def off_of(win):
    if not OFF_OF:
        w = 0
        for i in range(17): w |= BIG[i] << i
        for off in range(PERIOD):
            OFF_OF[w] = off
            w = (w >> 1) | (BIG[off + 17] << 16)
    return OFF_OF[win]

def main():
    frames = load(sys.argv[1] if len(sys.argv) > 1 else "output.bin")
    by_seq = {}
    for f in frames:
        by_seq.setdefault(f["seq"], f)
    secure = [f for f in frames if f["type"] == 2]
    print(f"[+] {len(frames)} frames, {len(secure)} SECURE: {[f['seq'] for f in secure]}")

    # Affine model over GF(2): input u(seq) = 1 | seq<<1 ; state(seq) = XOR of state(seq_i)
    # for any set of frames whose u's XOR to u(seq). Recover frames until every target is spanned.
    U = lambda s: 1 | (s << 1)
    basis = {}  # pivot -> (u, combined state)
    def reduce(u, v=0):
        while u:
            p = u.bit_length() - 1
            if p not in basis: return u, v
            bu, bv = basis[p]; u ^= bu; v ^= bv
        return 0, v
    used = []
    order = sorted(by_seq, key=lambda s: (bin(s).count("1") > 1, s))  # 0 and powers of 2 first
    for s in order:
        if all(reduce(U(f["seq"]))[0] == 0 for f in secure): break
        f = by_seq[s]
        if f["type"] != 1 or reduce(U(s))[0] == 0: continue
        off, x = recover(f)
        pt = bytes(a ^ b for a, b in zip(f["body"], keystream(off, x)))
        print(f"[+] seq {s:3d}: R0={r0_window(off):05x} R1R2={x:011x}  pt={pt[:f['plen']]}")
        u, v = reduce(U(s), r0_window(off) | (x << 17))
        basis[u.bit_length() - 1] = (u, v); used.append(s)

    def predict(seq):
        u, v = reduce(U(seq))
        assert u == 0, "not enough frames to span this seq"
        return off_of(v & 0x1FFFF), v >> 17

    # sanity check on a STATUS frame we did not use
    chk = next(f for f in frames if f["type"] == 1 and f["seq"] not in used and reduce(U(f["seq"]))[0] == 0)
    pt = bytes(a ^ b for a, b in zip(chk["body"], keystream(*predict(chk["seq"]))))
    print(f"[+] check seq {chk['seq']} via linear model: {pt[:chk['plen']]}")

    for f in secure:
        pt = bytes(a ^ b for a, b in zip(f["body"], keystream(*predict(f["seq"]))))
        print(f"[!] SECURE seq {f['seq']}: {pt}")

if __name__ == "__main__":
    main()

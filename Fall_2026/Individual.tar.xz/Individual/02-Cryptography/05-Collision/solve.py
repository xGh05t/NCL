import marshal, dis, sys

with open(sys.argv[1], 'rb') as f:
    f.read(16)
    code = marshal.load(f)

# Rebuild each list from LOAD_CONST ... BUILD_LIST n
lists, stack = {}, []
instrs = list(dis.get_instructions(code))
for i, ins in enumerate(instrs):
    if ins.opname == 'LOAD_CONST':
        stack.append(ins.argval)
    elif ins.opname == 'BUILD_LIST':
        name = instrs[i + 1].argval      # the STORE_NAME right after
        lists[name] = stack[-ins.arg:]
        stack = []
    else:
        stack = []

arr, comp = lists['arr'], lists['compArr']
print('arr     =', arr)
print('compArr =', comp)
print('flag    =', ''.join(chr(a ^ c) for a, c in zip(arr, comp)))

import marshal, dis, sys
with open(sys.argv[1], 'rb') as f:
    f.read(16)              # skip the 16-byte .pyc header
    code = marshal.load(f)
dis.dis(code)

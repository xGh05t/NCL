# WiFi PCAP 3 (Hard) — Answers & Evidence

100 points. Verified three times against the capture.

| Q | Answer | Evidence |
|---|--------|----------|
| Q1 – Router MAC (5) | **C0:4A:00:80:76:E4** | BSSID reported by `aircrack-ng`; matches beacon frames |
| Q2 – ESSID (5) | **TP-LINK_8076E4** | Beacon SSID; hex `54502d4c494e4b5f383037364534` decodes to it |
| Q3 – WiFi password (20) | **blueberrymuffin** | WPA handshake cracked with rockyou.txt; `airdecap-ng` then decrypted 5713 WPA packets, confirming the key |
| Q4 – Router IP (10) | **192.168.0.254** | Hosts the admin panel; all 39 `/userRpm/` requests target it |
| Q5 – Manufacturer (10) | **TP-Link** | Admin UI (`/dynaform/`, `/userRpm/StatusRpm.htm`) + OUI `C0:4A:00` |
| Q6 – Model (5) | **TL-WR702N** | `StatusRpm.htm` Hardware Version: `"WR702N 1.0 00000000"` |
| Q7 – Firmware version (10) | **4.19.1 Build 130528 Rel.52704n** | `StatusRpm.htm` Firmware Version: `"4.19.1 Build 130528 Rel.52704n "` |
| Q8 – Release number (5) | **52704n** | The `Rel.52704n` field of the firmware string |
| Q9 – Admin login IP (10) | **192.168.0.101** | Source IP of every GET to `/userRpm/StatusRpm.htm` (the admin panel) |
| Q10 – First deauth victim (10) | **B8:E8:56:47:44:38** | First deauth frame #147815 @ t=947.53s (AP → client) |
| Q11 – Second deauth victim (10) | **80:E6:50:0B:26:BA** | First deauth frame #148401 @ t=951.42s (AP → client) |

## Capture facts
- 168,733 frames total; WPA (one full EAPOL handshake captured) on BSSID `C0:4A:00:80:76:E4` / ESSID `TP-LINK_8076E4`
- Router is a TP-Link TL-WR702N nano router at `192.168.0.254`; wireless + LAN MAC `C0-4A-00-80-76-E4`, WAN MAC `C0-4A-00-80-76-E5`
- Admin session from client `192.168.0.101` browsing the web UI (`StatusRpm.htm`, `/dynaform/`, `/images/blue.jpg`)
- Deauth flood from the AP against two clients: `B8:E8:56:47:44:38` first, then `80:E6:50:0B:26:BA`

## Commands
```
# Q1, Q2, Q3 — identify network and crack the WPA handshake
aircrack-ng PCAP3.cap                                              # lists BSSID + ESSID, "WPA (1 handshake)"
aircrack-ng -w /usr/share/wordlists/rockyou.txt -b C0:4A:00:80:76:E4 PCAP3.cap   # KEY FOUND [ blueberrymuffin ]

# Decrypt for the admin-traffic questions
airdecap-ng -e TP-LINK_8076E4 -p blueberrymuffin PCAP3.cap        # -> decrypted.pcap (5713 WPA pkts)

# Q4, Q9 — router IP and who logged into the admin panel
tshark -r decrypted.pcap -Y http.request -T fields -e ip.src -e ip.dst -e http.request.uri | grep userRpm
#   192.168.0.101 -> 192.168.0.254   /userRpm/StatusRpm.htm   (x39)

# Q5, Q6, Q7, Q8 — manufacturer / model / firmware from the status page
tshark -r decrypted.pcap --export-objects http,ex
grep -aoE '"(WR702N|4\.19\.1)[^"]*"' ex/StatusRpm.htm
#   "4.19.1 Build 130528 Rel.52704n "   (firmware)
#   "WR702N 1.0 00000000"               (hardware/model)

# Q10, Q11 — deauth victims, in order of first appearance
tshark -r PCAP3.cap -Y "wlan.fc.type_subtype==0x0c && wlan.sa==c0:4a:00:80:76:e4" \
  -T fields -e frame.number -e frame.time_relative -e wlan.da | awk '!seen[$3]++'
#   b8:e8:56:47:44:38  frame 147815  t=947.53   <- first victim
#   80:e6:50:0b:26:ba  frame 148401  t=951.42   <- second victim
```

## Status page
The router's `StatusRpm.htm` only carries the raw data in JavaScript arrays (`statusPara`, `lanPara`, `wlanPara`, `wanPara`) and relies on the router's `common.js` to draw the table via `document.write`, so it opens blank as a local file. `StatusRpm.view.html` is a self-contained rebuild that renders those values in any browser. Key array values:
- `statusPara[5]` = firmware `4.19.1 Build 130528 Rel.52704n`, `statusPara[6]` = hardware `WR702N 1.0 00000000`
- `lanPara` = MAC `C0-4A-00-80-76-E4`, IP `192.168.0.254`, mask `255.255.255.0`
- `wlanPara` = SSID `TP-LINK_8076E4`, channel `5`

## Lesson
Hard tier bundles the whole attack chain: crack WPA from the captured handshake, decrypt, then read the plaintext admin traffic for the router fingerprint (TP-Link StatusRpm.htm gives model, hardware and firmware in one page). Q8's release is the full `52704n` string, letter included — digits-only `52704` was rejected. Deauth victims are ordered by which client the AP targeted first in time.

import runpy, sys, io, contextlib
encdir, fragf, target = sys.argv[1:4]
ranges = list(map(int, sys.argv[4:]))
sys.argv = ['solve.py', encdir, fragf]
with contextlib.redirect_stdout(io.StringIO()):
    g = runpy.run_path('solve.py')
pieces, results, BLK, KS, PIECE = g['pieces'], g['results'], g['BLK'], g['KS'], g['PIECE']
score_col = g['score_col']
CH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
def show(b): return ''.join(chr(x) if 32 <= x < 127 else '.' for x in b)
for a, z in zip(ranges[::2], ranges[1::2]):
    for o in range(a, z):
        pi, k = divmod(o, PIECE)
        for comp, pos, cols, S in results:
            i = next((i for i in comp if pieces[i][0] == target and pieces[i][1] == pi), None)
            if i is None: continue
            p = (pos[i] * BLK + k) % KS
            cb = pieces[i][2][k]
            oth = []
            for j in comp:
                if j == i: continue
                for kk in range(len(pieces[j][2])):
                    if (pos[j] * BLK + kk) % KS == p: oth.append((j, kk))
            col = [pieces[j][2][kk] for j, kk in oth]
            cands = sorted(((score_col(col, key) if score_col(col, key) > -1e8 else -1e4*sum(1 for c in col if not g['printable'](c ^ key)), chr(cb ^ key), key) for key in range(256)
                            if chr(cb ^ key) in CH), reverse=True)[:3]
            print(f"\n=== {target} @{o}  ({len(oth)} other pieces share this keystream byte)")
            for sc, ch, key in cands:
                print(f"  candidate {ch!r}  score {sc:.1f}")
                for j, kk in oth:
                    b = pieces[j][2]; base = pos[j] * BLK
                    ctx = bytearray(b[x] ^ S.get((base + x) % KS, 0) for x in range(max(0, kk - 8), min(len(b), kk + 9)))
                    c = kk - max(0, kk - 8); ctx[c] = b[kk] ^ key
                    print(f"     {pieces[j][0][:24]:24} {show(ctx[:c])}[{show(ctx[c:c+1])}]{show(ctx[c+1:])}")
            break
        else:
            print(f"\n=== {target} @{o}: piece not aligned")

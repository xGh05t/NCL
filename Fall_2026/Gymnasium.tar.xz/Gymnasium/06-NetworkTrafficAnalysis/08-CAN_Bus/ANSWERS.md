# CAN Bus (Hard) — Answers & Evidence

| Q | Answer | Evidence file |
|---|--------|---------------|
| Q1 – Unique CAN IDs | **36** | `Q1_unique_can_ids.csv` — 36 IDs, frame counts sum to 8192 |
| Q2 – Speed update messages | **352** | `Q2_speed_frames_id589.pcap` — only `can.id==589` frames (352 packets) |
| Q3 – Max speed (mph) | **20.13** | `Q3_speed_decoded.csv` (all 352 decoded), `Q3_max_speed_frame6860.txt` (tshark full dissection + hex) |

## Method (from `CANBUS_ProtocolSpec.md`)
- `speed_id = 589` (0x24D), `speed_pos = 3`
- `speed = ((data[3] << 8) + data[4]) / 100 * 0.6213751`
- Peak: frame **6860**, data `00 00 00 0c a8` → 0x0CA8 = 3240 → 32.40 km/h → 20.132553 mph → **20.13 mph**

## Cross-checks (all agree)
1. Custom parser — `verify_canbus.py` (no tshark; walks the Upper-PDU TLV header). Output in `verify_output.txt`.
2. tshark:
   ```
   tshark -r Candump.pcap -T fields -e can.id | sort -u | wc -l    # 36
   tshark -r Candump.pcap -Y 'can.id==589' | wc -l                 # 352
   tshark -r Candump.pcap -Y 'frame.number==6860' -V -x            # max-speed frame
   ```
3. Every frame has can_id flag bits (EFF/RTR/ERR) clear, so there are no extended or error IDs inflating Q1. All 352 speed frames have DLC 5, so data[3..4] exists.

## Reproduce
```
python3 verify_canbus.py Candump.pcap   # regenerates both CSVs and prints answers
```

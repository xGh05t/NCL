# Minutes

- We are going to be deciding on the theme of a challenge to send to potential candidates
- The flag will be: REDACTED (Can't leave the flag in the final document)
- The theme will be collaborative tools and their logs
- We can reuse the logs from this meeting

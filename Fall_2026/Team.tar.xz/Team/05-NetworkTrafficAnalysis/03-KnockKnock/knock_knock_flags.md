# NCL Fall 2026 – Knock knock (Hard)

Target: dev (10.12.230.130) | Source: kali (10.12.230.132)

| Q | Knock | Flag | Server message |
|---|---|---|---|
| Q1 | ICMP echo request (ping) | `SKY-IHDD-9520` | 10.12.230.132 successfully completed P_ping |
| Q2 | UDP dport 75 (rhenium) | `SKY-JDGL-8411` | 10.12.230.132 successfully completed P_udp75 |
| Q3 | UDP dport 31 (3rd Mersenne prime) | `SKY-SSQT-4766` | 10.12.230.132 successfully completed P_udp31 |
| Q4 | UDP dport 31337 (eleet) | `SKY-ZBLA-5190` | 10.12.230.132 successfully completed P_udp31337 |
| Q5 | UDP chargen (19) <-> echo (7) | `SKY-XGPE-9933` | 10.12.230.132 successfully completed P_udpechochargen |
| Q6 | ICMP type 15 Information Request + "question whose answer is 42" | `SKY-JBFA-8200` | 10.12.230.132 successfully completed P_questionof42 |

Note: flags come back as ICMP Information Reply (type 16) with a hex-encoded ASCII payload.

## Commands used (T=10.12.230.130)

```bash
nping --icmp -c1 $T                                   # Q1
nping --udp -p 75 -c1 $T                              # Q2
nping --udp -p 31 -c1 $T                              # Q3
nping --udp -p 31337 -c1 $T                           # Q4
nping --udp -g 19 -p 7 -c1 $T                         # Q5 (sport 19 chargen -> dport 7 echo)
nping --icmp --icmp-type 15 --data-string "What is the answer to life, the universe, and everything?" -c1 $T   # Q6
```

Replies captured with: `tcpdump -i eth0 -nn -l -X 'host 10.12.230.130 and not arp'`

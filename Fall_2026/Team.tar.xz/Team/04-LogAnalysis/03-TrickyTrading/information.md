# Information
## How the Game Works
Players can do dungeons or trade at the trade board. When they do dungeons, they earn xp, gold, and items. When they trade at the trade board, they will either earn gold and lose items or lose gold and earn items.

## How the Trade Board Works Normally
Instead of your typical trade board in which you must wait for other players to buy your gear, EI uses an NPC run trade board. The NPCs buy gear from players and sell it on to other players. Prices aren't fixed: the more of an item the NPCs hold, the cheaper it is, down to a minimum price for that item. The idea is that as an item becomes more common as the game gets older, the gear needed to compete gets cheaper for players who start later.

## Data
The following logs are being provided. They are stored in the game's custom binary log format:

- item_data.info - This gives you the reference data necessary to be able to understand what item is being purchased, how much it's worth, who can use it, etc.
- market_transactions.transactions - This lists every market transaction that occurred during the 24 hours, who performed it, what item they bought or sold, whether they bought or sold it, the number bought or sold, and the price bought or sold as
- market_updates.transactions - This lists every change the trade board made to its stock and prices.
- player_data.info - This lists the player data as of the start of the day of logging for each player that logged in during the 24 hours of logging
- player_transactions.transactions - This lists any updates that were made to the player data during the 24 hours of logging including what items were added and removed from their inventory, how much gold was added or removed, how much xp was added, etc.


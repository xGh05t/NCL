#!/usr/bin/env python3
"""
Tricky Trading - parser + per-question solutions.

Usage:
    python3 tricky_trading_solve.py <dir containing the 5 log files>

File format (all integers big-endian):
    "ZHDR" | u32 schema_len | schema (ASCII, e.g. "u u i i e ?t")
    then repeated records:
    "ZVAL" | u32 record_len | fields in schema order

Schema type codes:
    u      16-byte UUID
    i, t   signed 64-bit int (t = unix timestamp)
    s, e   u16 length + UTF-8 string (e = enum such as MAGE / BUY / SELL)
    ?X     1-byte presence flag (0 = absent), then X if present
    m      u32 count, then count x (UUID, i64)    -> item:qty map
    l(..)  u32 count, then count x tuple of the inner types
"""
import os, sys, struct, uuid, bisect
from collections import Counter, defaultdict


# --------------------------------------------------------------------------
# Parser
# --------------------------------------------------------------------------
def tokenize(schema):
    """Turn 'l(u i i) ?t' into a list of type tokens."""
    toks, k = [], 0
    while k < len(schema):
        if schema[k] == ' ':
            k += 1
            continue
        tok, k = _one(schema, k)
        toks.append(tok)
    return toks

def _one(schema, k):
    c = schema[k]
    if c == '?':
        sub, k = _one(schema, k + 1)
        return ('?', sub), k
    if c == 'l':                      # l( ... ) with matching parens
        depth, j = 0, k + 1
        while True:
            if schema[j] == '(':
                depth += 1
            elif schema[j] == ')':
                depth -= 1
                if depth == 0:
                    break
            j += 1
        return ('l', tokenize(schema[k + 2:j])), j + 1
    return c, k + 1

def read_field(t, b, o):
    if isinstance(t, tuple):
        if t[0] == '?':
            present = b[o]; o += 1
            return read_field(t[1], b, o) if present else (None, o)
        if t[0] == 'l':
            n = struct.unpack('>I', b[o:o + 4])[0]; o += 4
            rows = []
            for _ in range(n):
                row = []
                for st in t[1]:
                    v, o = read_field(st, b, o); row.append(v)
                rows.append(tuple(row))
            return rows, o
    if t == 'u':
        return str(uuid.UUID(bytes=b[o:o + 16])), o + 16
    if t in ('i', 't'):
        return struct.unpack('>q', b[o:o + 8])[0], o + 8
    if t in ('s', 'e'):
        n = struct.unpack('>H', b[o:o + 2])[0]
        return b[o + 2:o + 2 + n].decode(), o + 2 + n
    if t == 'm':
        n = struct.unpack('>I', b[o:o + 4])[0]; o += 4
        d = {}
        for _ in range(n):
            key = str(uuid.UUID(bytes=b[o:o + 16])); o += 16
            val = struct.unpack('>q', b[o:o + 8])[0]; o += 8
            d[key] = d.get(key, 0) + val
        return d, o
    raise ValueError('unknown type ' + str(t))

def parse(path):
    b = open(path, 'rb').read()
    assert b[:4] == b'ZHDR'
    n = struct.unpack('>I', b[4:8])[0]
    schema = b[8:8 + n].decode()
    toks, o, recs = tokenize(schema), 8 + n, []
    while o < len(b):
        assert b[o:o + 4] == b'ZVAL', 'bad record marker at %d' % o
        ln = struct.unpack('>I', b[o + 4:o + 8])[0]
        start = o = o + 8
        row = []
        for t in toks:
            v, o = read_field(t, b, o); row.append(v)
        assert o == start + ln, 'record length mismatch at %d' % start
        recs.append(row)
    return schema, recs

def load(d):
    want = ['item_data.info', 'market_transactions.transactions',
            'market_updates.transactions', 'player_data.info',
            'player_transactions.transactions']
    out = {}
    for f in os.listdir(d):
        for w in want:
            if f.endswith(w):
                schema, recs = parse(os.path.join(d, f))
                print('[+] %-34s schema=%-22r records=%d' % (w, schema, len(recs)))
                out[w] = recs
    return out


# --------------------------------------------------------------------------
# Field layout (worked out from the data):
#   item_data            : name, value, tier, class, slot, item_uuid
#   market_transactions  : player, item, qty, unit_price, BUY|SELL, ts
#   market_updates       : [(item, stock, price), ...], ts   (every 5 s)
#   player_data          : player, username, level, xp, gold, class,
#                          outfit, mainhand, inventory{item: qty}
#   player_transactions  : tx_id, player, xp?, gold?, added{}?, removed{}?, ts
# --------------------------------------------------------------------------
def main(d):
    D = load(d)
    items = {r[5]: r[0] for r in D['item_data.info']}
    players = {r[0]: r for r in D['player_data.info']}
    uname = {r[1]: r[0] for r in D['player_data.info']}
    mt = sorted(D['market_transactions.transactions'], key=lambda r: r[5])
    mu = D['market_updates.transactions']
    pt = D['player_transactions.transactions']

    print()
    # Q1: sum every gold delta in player_transactions
    q1 = sum(r[3] for r in pt)
    print('Q1  total gold change            :', q1)

    # Q2: player_data holds one record per player who logged in
    print('Q2  unique users online          :', len(players))

    # Q3: total quantity on SELL rows
    print('Q3  total qty sold to market     :',
          sum(r[2] for r in mt if r[4] == 'SELL'))

    # Glitch detection: SELL immediately followed by BUY of the same item and
    # same qty at a LOWER unit price (sell high, buy back low, repeat).
    by_player = defaultdict(list)
    for r in mt:
        by_player[r[0]].append(r)
    cycles = Counter()
    for p, rows in by_player.items():
        for a, b in zip(rows, rows[1:]):
            if (a[4] == 'SELL' and b[4] == 'BUY' and a[1] == b[1]
                    and a[2] == b[2] and b[3] < a[3]):
                cycles[p] += 1
    # Clear gap in the distribution: legit players have <= a handful,
    # glitch users have hundreds.
    glitchers = {p for p, c in cycles.items() if c >= 20}
    print('Q4  glitch users                 :', len(glitchers))

    # Solo vs ring: count how many OTHER players sold the same item in the
    # same 5-second price window. Ring members overlap heavily; solo ~0.
    sellers = defaultdict(set)
    for p, i, q, pr, side, ts in mt:
        if side == 'SELL':
            sellers[(i, ts // 5)].add(p)
    def avg_cosellers(p):
        c = [len(sellers[(i, ts // 5)] - {p})
             for _, i, q, pr, side, ts in by_player[p] if side == 'SELL']
        return sum(c) / len(c)
    solo = [p for p in glitchers if avg_cosellers(p) < 1]
    ring = glitchers - set(solo)
    s = solo[0]
    print('Q5  solo farmer                  :', players[s][1])

    s_items = Counter(items[r[1]] for r in by_player[s] if r[4] == 'SELL')
    print('Q6  solo farmer item             :', s_items.most_common(1)[0][0])

    s_spent = sum(r[2] * r[3] for r in by_player[s] if r[4] == 'BUY')
    print('Q7  solo total spent             :', s_spent)

    s_net = sum(r[3] for r in pt if r[1] == s)
    s_trade = sum((r[2] * r[3]) * (1 if r[4] == 'SELL' else -1) for r in by_player[s])
    print('Q8  solo net gold change         :', s_net,
          '(trading only: %d)' % s_trade)

    start_inv = players[s][8]
    bought = []
    for r in by_player[s]:
        if r[4] == 'BUY' and r[1] not in start_inv and r[1] not in bought:
            bought.append(r[1])
    print('Q9  bought, not in start inv     :', ', '.join(bought))
    for i in bought:
        print('       ', i, items[i])

    print('Q10 ring members                 :', len(ring))

    ring_items = Counter(items[r[1]] for p in ring for r in by_player[p])
    print('Q11 ring items                   :',
          ', '.join(n for n, _ in ring_items.most_common(2)))

    r_spent = sum(r[2] * r[3] for p in ring for r in by_player[p] if r[4] == 'BUY')
    r_earned = sum(r[2] * r[3] for p in ring for r in by_player[p] if r[4] == 'SELL')
    print('Q12 ring total spent             :', r_spent)
    print('Q13 ring net profit (trading)    :', r_earned - r_spent,
          '(incl. dungeon gold: %d)' % sum(r[3] for r in pt if r[1] in ring))

    # Root cause check: every trade is priced at the most recent 5-second
    # snapshot, regardless of how much stock moved inside that window.
    times = [t for _, t in mu]
    price, hist = {}, []
    for lst, t in mu:
        for i, stock, p in lst:
            price[i] = p
        hist.append(dict(price))
    stale = sum(1 for _, i, q, pr, side, ts in mt
                if pr == hist[bisect.bisect_left(times, ts) - 1][i])
    print('\n[i] trades priced at last 5 s snapshot: %d / %d' % (stale, len(mt)))
    print('[i] ring usernames:', ', '.join(sorted(players[p][1] for p in ring)))


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else '.')

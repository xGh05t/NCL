import json, sys
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
key = bytes.fromhex(sys.argv[1])
vault = json.load(open("vault_decrypted.json"))
for iid, item in vault["items"].items():
    if "url_nonce" not in item:
        continue
    ct = bytes.fromhex(item["url"])
    nonce = bytes.fromhex(item["url_nonce"])
    print(f"{iid} ({item['name']}): ct={len(ct)} bytes, nonce={len(nonce)} bytes")
    print("   ", AESGCM(key).decrypt(nonce, ct, None).decode())

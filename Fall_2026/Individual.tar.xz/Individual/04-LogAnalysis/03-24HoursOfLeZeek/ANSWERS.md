# **24 Hours of Le Zeek (Hard)**
Challenge: NCL Fall 2026 Individual Game, Log Analysis, 100 points

Author: xG//05t  
Date: October 24, 2026

> **Note:** Every answer below was accepted. Evidence comes from the supplied Zeek logs (`pi_ub2004_64.tar.gz`).

# **Summary**

The tarball holds 24 hours of hourly rotated Zeek logs in JSON, with every field key renamed to `f1`, `f2`, and so on. The `f7` key still holds the log type, and the file names (`conn.*`, `http.*`, `dns.*`, `dhcp.*`, `ntp.*`, `ssl.*`, `software.*`, `weird.*`) identify each log. Field meanings were recovered from the values in each log.

# **Field Map**

```
common : f1=ts  f7=log type  f9=uid  f10/f11=orig ip/port  f12/f13=resp ip/port
http   : f79=method  f80=host  f81=uri  f84=user_agent
dns    : f42=query  f46=qtype  f54=answers
dhcp   : f32=mac  f33=host_name  f34=client_fqdn  f35=domain  f40=msg types
ssl    : f132=server_name (SNI)
software: f80=host  f122=type  f123=name
weird  : f123=name
```

# **Solve Chain**

```
tar -xzf pi_ub2004_64.tar.gz
http.*      -> Q1, Q2
ntp.*       -> Q3
Q3 IP owner -> Q4
software.*  -> Q5
ssl.*       -> Q6
dns.* mDNS  -> Q7
dhcp.*      -> Q8, Q9
weird.* uid -> http.* -> Q10
```

# **1. Unencrypted Web Service**

**Answer:** `skyaware`

```bash
head -n 3 http.00:00:00-01:00:00.log
```

Every request is `GET /skyaware/data/aircraft.json` to port 80. SkyAware is the FlightAware ADS-B aircraft tracking web UI that runs on top of `dump1090`.

# **2. Web Server Address**

**Answer:** `10.0.0.238`

The responder (`f12`) on every `http` record is `10.0.0.238` on port 80. `known_services` lists HTTP on `10.0.0.238:80/tcp`, and `software` reports the server as `lighttpd/1.4.55`.

# **3. External NTP Server**

**Answer:** `91.189.91.157`

```bash
head -n 4 ntp.00:00:00-01:00:00.log
```

`10.0.0.238` sends NTP client requests to `91.189.91.157:123`. The `132.163.96.1` value in the server reply is the reference ID of that server's own upstream (NIST), not the server this network uses.

# **4. Linux Variant on 10.0.0.238**

**Answer:** `Ubuntu`

`91.189.91.0/24` belongs to Canonical and serves `ntp.ubuntu.com`, the default time source on Ubuntu. The same host also makes TLS connections to `motd.ubuntu.com`, `esm.ubuntu.com`, and `api.snapcraft.io`, and the tarball name `pi_ub2004_64` points to Ubuntu 20.04 64-bit on a Raspberry Pi.

# **5. Browser on 10.0.0.111**

**Answer:** `Chrome`

```bash
cat software.*
```

`software` records `HTTP::BROWSER` = `Chrome` version 131 for `10.0.0.111`, from the user agent `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) ... Chrome/131.0.0.0 Safari/537.36`.

# **6. Encrypted Firmware Update Server**

**Answer:** `cdn.fwupd.org`

```bash
grep -ho '"f132": "[^"]*"' ssl.* | sort | uniq -c | sort -rn
```

```
      6 "f132": "api.snapcraft.io"
      3 "f132": "motd.ubuntu.com"
      2 "f132": "cdn.fwupd.org"
      1 "f132": "esm.ubuntu.com"
      1 "f132": "download.docker.com"
```

`cdn.fwupd.org` is the LVFS (Linux Vendor Firmware Service) CDN that `fwupd` polls for firmware metadata over TLS.

# **7. RAOP Device Other Than the MacBook**

**Answer:** `J105aAP, Apple TV 4K`

```bash
grep -h -i raop dns.* | grep -v '"f54": \["-"\]' | head
grep -h -o '"TXT [^"]*"' dns.* | grep -v 'Mac16' | sort -u
```

mDNS (port 5353) shows two `_raop._tcp.local` advertisements: `william's macbook pro` and `76417e788b7b@living room._raop._tcp.local` from `10.0.0.17`. The only non Mac model string in the TXT records is `model=J105aAP`. J105aAP is Apple's hardware model code for the Apple TV 4K (1st generation, 2017), product identifier `AppleTV6,2`.

# **8. System Keeping a DNS Name**

**Answer:** `dartmouth.edu`

```bash
grep -ho '"f32": "[^"]*", "f33": "[^"]*", "f34": "[^"]*", "f35": "[^"]*"' dhcp.* | sort | uniq -c
```

Only one client populates `f34`, the DHCP Client FQDN (option 81): MAC `70:a8:d3:2d:18:5b`, hostname `G38FKN3`, FQDN `G38FKN3.kiewit.dartmouth.edu`. Every other client sends a bare hostname or nothing.

# **9. Network Infrastructure Device in DHCP**

**Answer:** `5c:a6:e6:67:fa:8b`

From the same DHCP output:

```
      1 "f32": "5c:a6:e6:67:fa:8b", "f33": "TL-SG1016DE", "f34": "-", "f35": "-"
```

`TL-SG1016DE` is a TP-Link 16 port managed switch, and `5c:a6:e6` is a TP-Link OUI. The other clients are an ESP32 (`esp32s2-D9BFF2`), a ChargePoint EV charger (`cs_0024b100000cbbe9`), iPhones, a laptop, and randomized MACs.

# **10. Anomaly on the First Exchange**

**Answer:** `WSD` (Web Services for Devices)

```bash
cat weird.*
grep -h CqTNV91nQT9tOsqGwg *.log
```

The only `weird` log flags `possible_split_routing` and `data_before_established` on uid `CqTNV91nQT9tOsqGwg`, an IPv6 link local connection to `[fe80::fada:cff:fe33:9ce8]:80`. The matching `http` record is the first request on the connection:

```
POST /WebServices/PrinterService   UA=WSDAPI   Content-Type: application/soap+xml
```

`WSDAPI` and `/WebServices/PrinterService` are Microsoft's Web Services for Devices printer API, built on SOAP and WS-Discovery.

# **Answer Key**

| Q | Answer |
|---|---|
| 1 | `skyaware` |
| 2 | `10.0.0.238` |
| 3 | `91.189.91.157` |
| 4 | `Ubuntu` |
| 5 | `Chrome` |
| 6 | `cdn.fwupd.org` |
| 7 | `J105aAP, Apple TV 4K` |
| 8 | `dartmouth.edu` |
| 9 | `5c:a6:e6:67:fa:8b` |
| 10 | `WSD` |

# Pandora's Box

The hackers have created their own custom protocol for private communication. Luckily, our analysts have managed to obtain the documentation describing the protocol. Use it to fill out this report.

## Overview

The communication between the client and server will contain three types of messages: Initialization, Encrypt Request, and Encrypt Response. A connection is started with the client sending an Initialization message, which contains the number of Encrypt Requests that the client wishes to make. Then, the server will send the length of its response. Then, the client sends their Encrypt Requests to the server. After all of the Encrypt Requests have been received, the server will finish sending a single Encrypt Response which contains hashes of all of the data that was sent by the client.

## Initialization (Client → Server)

1. **N** — A 4-byte integer in network byte order that represents the number of Encrypt Requests that will be sent.

## Encrypt Request (Client → Server)

1. **Check** — A fixed 2-byte integer in network byte order that verifies the integrity of the message.
2. **Len** — A 4-byte integer in network byte order that represents the length of the data in bytes.
3. **Data** — The data that will be encrypted.

## Encrypt Response (Server → Client)

1. **Count** — The length of the data, in bytes, that follows.
2. **Hashes** — The encrypted hashes requested by the client. Each hash is in the form of a fixed-length chunk. These hashes are in the same order that the requests were made.


#!/usr/bin/env python3
"""Independent verifier for NCL Gymnasium 'CAN Bus (Hard)'.
Parses Candump.pcap (LINKTYPE_WIRESHARK_UPPER_PDU / can-hostendian) without tshark,
applies the decode logic from CANBUS_ProtocolSpec.md, and writes the evidence CSVs.
Usage: python3 verify_canbus.py [Candump.pcap]"""
import struct, sys, collections, csv
path = sys.argv[1] if len(sys.argv) > 1 else "Candump.pcap"
d = open(path, "rb").read()
SPEED_ID, SPEED_POS = 589, 3
o, frame = 24, 0
ids = collections.Counter(); rows = []
while o < len(d):
    ts, tu, il, _ = struct.unpack("<IIII", d[o:o+16]); p = d[o+16:o+16+il]; o += 16 + il; frame += 1
    q = 0
    while True:  # walk exported-PDU TLV tags (big-endian) until end-of-options
        t, l = struct.unpack(">HH", p[q:q+4]); q += 4
        if t == 0: break
        q += l
    cid = struct.unpack("<I", p[q:q+4])[0] & 0x1FFFFFFF
    dlc = p[q+4]; data = p[q+8:q+8+dlc]
    ids[cid] += 1
    if cid == SPEED_ID:
        raw = (data[SPEED_POS] << 8) + data[SPEED_POS + 1]
        rows.append([frame, f"{ts}.{tu:06d}", cid, dlc, data.hex(), raw, f"{raw/100:.2f}", f"{raw/100*0.6213751:.6f}"])
with open("Q1_unique_can_ids.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["can_id_hex", "can_id_dec", "frame_count"])
    for k in sorted(ids): w.writerow([f"0x{k:03X}", k, ids[k]])
with open("Q3_speed_decoded.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["frame", "epoch_time", "can_id", "dlc", "data_hex", "raw_speed_data3_4", "kmh", "mph"])
    w.writerows(rows)
best = max(rows, key=lambda r: r[5])
print(f"File              : {path}")
print(f"Total frames      : {frame}")
print(f"Q1 unique CAN IDs : {len(ids)}")
print(f"Q2 speed messages : {len(rows)}  (can_id == {SPEED_ID} / 0x{SPEED_ID:X})")
print(f"Q3 max speed      : {best[7]} mph -> {float(best[7]):.2f}  (frame {best[0]}, data {best[4]}, raw {best[5]} = {best[6]} km/h)")

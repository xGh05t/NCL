# **Steg 2**

Room: NCL Fall 2026 Practice Game, Cryptography, Steg 2 (Medium, 35 points)

Author: `xG//05t`  
Date: October 14, 2026

> **Educational purpose:** This document records work against a sanctioned NCL Fall 2026 practice challenge for training and after action review.

> **Prompt:** We have come across this image which we think may contain a flag. Try to make some sense out of it. Q1: What encryption algorithm was used to hide a message in the cover image? Q2: What is the hidden flag in the image?

# **Summary**

The challenge file `Steg2.bmp` is a 1280x854 24-bit Windows BMP of a black and white night photo (Church of the Savior on Spilled Blood, St. Petersburg). The message was hidden with the Digital Invisible Ink Toolkit (`DIIT`), a Java GUI steganography tool, using its default `BattleSteg` algorithm and a blank password. In `DIIT` the "algorithm" is the hiding algorithm, not a cipher, so that is the Q1 answer. Every standard command line stego tool returns nothing on this file because `DIIT` scatters payload bits by password seeded PRNG and favors high contrast edges.

| Item | Value |
|------|-------|
| Q1 algorithm | `BattleSteg` |
| Q2 flag | `SKY-ETYN-6949` |
| Tool | Digital Invisible Ink Toolkit 1.5 (`diit-1.5.jar`) |
| Password | blank |
| Hints used | Free "General Direction", 5 point "Tool" |

# **Attack Chain**

```
file / exiftool / binwalk / strings  -> clean BMP, no appended data, no metadata
steghide / stegseek (wordlist+seed)  -> no steghide payload under any seed
zsteg -a / Aperi'Solve / StegOnline  -> no sequential LSB payload, bit planes look natural
pixel analysis                       -> grayscale image, only 60 off gray pixels, clustered on edges
free hint                            -> "more than the command line" -> GUI tool
S-Tools 4 under Wine                 -> dead end
paid hint                            -> "Digital Invisible Ink" -> DIIT
DIIT decode, BattleSteg, blank pass  -> SKY-ETYN-6949
```

# **1. Triage**

```
file Steg2.bmp
md5sum Steg2.bmp
exiftool Steg2.bmp
binwalk Steg2.bmp
strings -n 6 Steg2.bmp | head
```

```
Steg2.bmp: PC bitmap, Windows 3.x format, 1280 x 854 x 24, image size 3279360, cbSize 3279414, bits offset 54
971a142583fca8aa4aa19598a7f28aa8  Steg2.bmp
```

`exiftool` shows no comment or metadata fields. Header size (54) plus image length (3279360) equals the file size (3279414), so nothing is appended. The only `binwalk` hit is `Intel x86 or x64 microcode` at `0x2273C9`, a false positive on a run of dark gray pixels (`02 02 02 ...`). `strings` returns only pixel noise.

# **2. Standard stego tooling (all negative)**

Steghide, wordlist and seed modes:

```
steghide info Steg2.bmp
stegseek Steg2.bmp /usr/share/wordlists/rockyou.txt
stegseek --seed Steg2.bmp
```

`stegseek --seed` walks every possible steghide PRNG seed and checks for the steghide magic without a password. It finished with `Could not find a valid seed`, which rules out steghide under any passphrase. A control file embedded with `steghide -e none -Z -K -N` into a copy of the same image was found by `--seed`, so the negative result is trustworthy.

LSB sweeps:

```
zsteg -a Steg2.bmp
```

Every hit is a false positive (`VISX image file`, `OpenPGP Public Key`, `zlib compressed data`, repeated characters from the dark sky). `zsteg` crashes on Ruby 3.3 with `can't create instance of singleton class (TypeError)` from `zpng`; the partial output up to the crash already covers the sequential channel orders.

Aperi'Solve rejects the 3.2 MB BMP. Convert losslessly and upload the PNG:

```
convert Steg2.bmp Steg2.png
```

Aperi'Solve and StegOnline both came back empty. OpenStego, Stegosuite and SilentEye were also ruled out by test embedding into copies of the image and comparing the pixel footprint against the challenge file.

# **3. Pixel analysis**

The photo is grayscale stored as 24-bit RGB, so every pixel should have `R == G == B`:

```
python3 -c "
from PIL import Image
px = list(Image.open('Steg2.bmp').convert('RGB').getdata())
ng = [i for i,p in enumerate(px) if not p[0]==p[1]==p[2]]
print(len(ng), 'non gray of', len(px))
"
```

```
60 non gray of 1093120
```

All 60 are single channel `+/-1` changes (for example `(9,8,8)`, `(2,3,3)`, `(230,231,231)`). Many sit in tight diagonal clusters along overhead wires and lamp edges. JPEG decoding of a neutral image does not produce single channel `+/-1` shifts, so these are embedding artifacts. Edge clustering plus a tiny footprint points at an edge adaptive hider rather than plain random LSB.

# **4. Hint 1 and the S-Tools dead end**

Free hint: `You might need something more than the command line for this one...`

`S-Tools 4` was the first GUI candidate because its Reveal dialog asks for an encryption algorithm (`IDEA`, `DES`, `Triple DES`, `MDC`). It is a 32-bit Windows binary, so Wine needs the i386 multiarch:

```
sudo dpkg --add-architecture i386
sudo apt update
sudo apt install -y wine wine32:i386
rm -rf ~/.wine && wineboot -i
wget https://www.garykessler.net/download/s-tools4.zip
unzip s-tools4.zip
wine S-Tools.exe 'Z:\home\kali\Desktop\NCL_Fall_2026\Practice\02-Cryptography\02-Steg2\Steg2.bmp'
```

Passing the image path on the command line loads it without drag and drop. A scripted run of 41 themed and common passphrases against all four algorithms (164 Reveals) produced nothing. A wrong passphrase in S-Tools closes the dialog silently.

# **5. Hint 2 and DIIT (Q1, Q2)**

Paid hint (5 points): `Digital Invisible Ink should help here`

The Digital Invisible Ink Toolkit is a Java GUI tool with six hiding algorithms: `BattleSteg` (default), `BlindHide`, `DynamicBattleSteg`, `DynamicFilterFirst`, `FilterFirst`, `HideSeek`. It has no cipher; the password is MD5 hashed into a PRNG seed that picks pixel and bit positions. `BattleSteg` places bits around high contrast "ships" in the image, which matches the edge clusters from section 3.

`sourceforge.net/projects/diit/files/latest/download` returns 403 to `curl`. Pull the jar from the download mirror directly:

```
mkdir diit && cd diit
wget https://downloads.sourceforge.net/project/diit/diit/1.5/diit-1.5.jar
java -jar diit-1.5.jar
```

Decode tab:

1. **Get Image**: `Steg2.bmp`
2. **Password**: leave blank
3. **Algorithm**: `BattleSteg`
4. **Set Output**: `flag.txt`
5. **Go**

```
cat flag.txt
SKY-ETYN-6949
```

To sweep all six algorithms and a password list without clicking through the GUI, call the decoder directly against the jar:

```
cat > Try.java <<'EOF'
import invisibleinktoolkit.stego.*;
import java.io.*; import java.security.*; import javax.imageio.ImageIO;
public class Try {
  static long seed(String p) throws Exception {
    byte[] m = MessageDigest.getInstance("MD5").digest(p.getBytes());
    StringBuilder sb = new StringBuilder(); for (byte b : m) sb.append(String.format("%02x", b));
    return Long.parseLong(sb.substring(0, 15), 16);
  }
  public static void main(String[] a) throws Exception {
    StegoImage img = new StegoImage(ImageIO.read(new File(a[0])));
    String[] algs = {"BattleSteg","BlindHide","DynamicBattleSteg","DynamicFilterFirst","FilterFirst","HideSeek"};
    BufferedReader br = new BufferedReader(new FileReader(a[1])); String pass;
    while ((pass = br.readLine()) != null) for (String al : algs) {
      StegoAlgorithm s = (StegoAlgorithm) Class.forName("invisibleinktoolkit.algorithms." + al).getDeclaredConstructor().newInstance();
      String out = al + "_" + pass.replaceAll("[^A-Za-z0-9]", "_") + ".bin";
      try { s.decode(img, seed(pass), out); System.out.println("HIT " + al + " [" + pass + "] " + new File(out).length() + " bytes"); }
      catch (NoMessageException e) { new File(out).delete(); }
    }
  }
}
EOF
printf '\npassword\nncl\nsteg\n' > pw.txt
javac -cp diit-1.5.jar Try.java
java -Djava.awt.headless=true -cp diit-1.5.jar:. Try ../Steg2.bmp pw.txt
```

```
HIT BattleSteg [] 13 bytes
```

The blank first line of `pw.txt` is the empty password. The GUI password field also hashes an empty string with MD5 (its `pass == ""` check compares references and never matches), so the seed reproduces exactly.

**Q1 answer: `BattleSteg`.**  
**Q2 answer: `SKY-ETYN-6949`.**

> **Note:** For future stego problems, a 24-bit BMP or PNG that defeats `steghide`, `stegseek --seed` and `zsteg`, with a handful of single channel `+/-1` pixels clustered on edges, is a `DIIT` signature. Run all six algorithms with a blank password first.

# **6. Cleanup**

Wine and the i386 multiarch were only needed for the S-Tools attempt:

```
sudo apt purge 'wine*'
sudo apt purge --allow-remove-essential gcc-16-base:i386 libc-gconv-modules-extra:i386 libc6:i386 libgcc-s1:i386 libidn2-0:i386 libunistring5:i386
sudo apt autoremove --purge
sudo dpkg --remove-architecture i386
sudo apt update
rm -rf ~/.wine stools
dpkg --print-foreign-architectures
```

`dpkg --remove-architecture i386` fails with `currently in use by the database` until the leftover `:i386` base libraries are purged. Newer apt refuses to remove them without `--allow-remove-essential` because they are flagged essential, even though only the 64-bit copies are in use.

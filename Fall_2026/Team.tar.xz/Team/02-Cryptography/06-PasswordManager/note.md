### NOTE:

- The files we have include the server log, Liber8tion's published recovery-key fingerprints, and private-key fragments from a Domin8tion workstation we seized.

- Fingerprints are the hex SHA-256 of the DER-encoded SubjectPublicKeyInfo. Recovery ciphertexts use RSA-OAEP with SHA-256 for both the hash and MGF1.

# WiFi PCAP 1 (Easy) — Answers & Evidence

All answers confirmed correct on submission.

| Q | Answer | Evidence |
|---|--------|----------|
| Q1 – Number of IVs | **14337** | `aircrack-ng` reports `WEP (14337 IVs)`; tshark: 14500 IV fields, 14337 unique |
| Q2 – Key size (bits) | **64** | WEP-64 = 40-bit secret key + 24-bit IV (cracked key is 5 bytes). Note: `40` was rejected |
| Q3 – IV of first packet | **003a33** | Frame 1 raw bytes at offset 0x1A: `00 3a 33`, then key index `00` |
| Q4 – WEP key | **A4:81:53:B4:CF** | `aircrack-ng` KEY FOUND, "Decrypted correctly: 100%"; airdecap-ng decrypted 14338 WEP packets, 0 corrupted |
| Q5 – TCP checksum of first packet | **897b** | Decrypted frame 1 (192.168.0.101:56985 → 192.168.0.102:22, SSH): `Checksum: 0x897b [correct]` |

## Capture facts
- 14500 frames: 1 × 0x0020 Data + 14499 × 0x0028 QoS Data, all WEP-encrypted
- BSSID `C0:4A:00:80:76:E4`, no ESSID broadcast

## Commands
```
aircrack-ng PCAP1.pcap                                         # Q1, Q4 (PTW attack)
tshark -r PCAP1.pcap -Y wlan.wep.iv -T fields -e wlan.wep.iv | sort -u | wc -l   # 14337
tshark -r PCAP1.pcap -c1 -x                                    # Q3 raw bytes
airdecap-ng -w A4:81:53:B4:CF -o decrypted.pcap PCAP1.pcap
tshark -r decrypted.pcap -c1 -o tcp.check_checksum:TRUE -V | grep -i checksum    # Q5
```

## Cross-check (Q4/Q5)
Wireshark decryption with key `a4:81:53:b4:cf` → frame 1 WEP ICV `0x9ad2e8d3 (correct)`, TCP checksum `0x897b` recalculated and Good — matches airdecap-ng output.

## Lesson
NCL "key size of the encryption method" for WEP means WEP-64 / WEP-128 (IV included), not the 40/104-bit secret key length.

#!/usr/bin/env python3
"""Password Manager (Hard) - one-shot solver.
usage (from OUTSIDE the evidence dir):  python3 -I solve.py ~/logs
1. Stitch carved PEM fragments (by offset contiguity + brute pairing), load every private key.
2. Fingerprint each key; compare to org_directory.json (published Liber8tion keys).
3. RSA-OAEP(SHA-256/MGF1-SHA-256) try every key on every recovery ciphertext.
4. AES-256-GCM decrypt encrypted_vault.bin with each recovered 32-byte key, AAD = each user_id in server.log.
5. Cross-reference server.log enroll/key_rotated lines.
"""
import re, json, base64, hashlib, binascii, itertools, sys, os
D = os.path.expanduser(sys.argv[1] if len(sys.argv) > 1 else ".")
def P(name): return os.path.join(D, name)
from cryptography.hazmat.primitives import serialization as S, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

OAEP = padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
def fp(pub): return hashlib.sha256(pub.public_bytes(S.Encoding.DER, S.PublicFormat.SubjectPublicKeyInfo)).hexdigest()

# ---------- 1. fragments ----------
txt = open(P("workstation_recovered_keys.txt")).read()
frags = []
for m in re.finditer(r"--- (\S+) \(offset=(0x[0-9a-fA-F]+) length=(\d+)\) ---\n(.*?)(?=\n--- |\Z)", txt, re.S):
    frags.append(dict(name=m.group(1), off=int(m.group(2), 16), len=int(m.group(3)), body=m.group(4)))
print(f"[*] {len(frags)} fragments")
for f in frags:
    f["has_begin"] = "BEGIN PRIVATE KEY" in f["body"]; f["has_end"] = "END PRIVATE KEY" in f["body"]
    print(f"    {f['name']} off={hex(f['off'])} len={f['len']} begin={f['has_begin']} end={f['has_end']}")

def load(pemtext):
    m = re.search(r"-----BEGIN PRIVATE KEY-----(.*?)-----END PRIVATE KEY-----", pemtext, re.S)
    if not m: return None
    b = re.sub(r"[^A-Za-z0-9+/=]", "", m.group(1))
    try: return S.load_der_private_key(base64.b64decode(b + "=" * (-len(b) % 4)), None)
    except Exception: return None

cands = {}
for f in frags:
    if f["has_begin"] and f["has_end"]: cands[f["name"]] = f["body"]
for a, b in itertools.permutations(frags, 2):
    if a["has_begin"] and not a["has_end"] and b["has_end"] and not b["has_begin"]:
        tag = "contiguous" if a["off"] + a["len"] == b["off"] else "brute"
        cands[f"{a['name']}+{b['name']} ({tag})"] = a["body"] + "\n" + b["body"]

dirj = json.load(open(P("org_directory.json")))
published = {v["fingerprint_sha256"].lower(): k for k, v in dirj.items()}
keys = {}
print("\n[*] Loadable private keys:")
for name, body in cands.items():
    k = load(body)
    if not k:
        print(f"    {name}: FAILED to parse (corrupt/decoy)"); continue
    f_ = fp(k.public_key())
    if f_ in [fp(x.public_key()) for x in keys.values()]: continue
    keys[name] = k
    print(f"    {name}: {k.key_size}-bit fp={f_}  -> {'PUBLISHED: ' + published[f_] if f_ in published else 'NOT a published org key'}")

# ---------- 2. recovery ciphertexts ----------
rc = json.load(open(P("recovery_ciphertexts.json")))
hits = []
print("\n[*] Trying every key on every recovery ciphertext ...")
for cid, hx in rc.items():
    c = binascii.unhexlify(re.sub(r"\s", "", hx))
    for kn, k in keys.items():
        if len(c) != k.key_size // 8: continue
        try:
            pt = k.decrypt(c, OAEP)
            hits.append((cid, kn, pt)); print(f"    HIT id={cid} key={kn} pt_len={len(pt)} pt={pt.hex()}")
        except Exception: pass

# ---------- 3. log ----------
log = open(P("server.log")).read().splitlines()
users = []
for l in log:
    for u in re.findall(r"user_id=([^\s,]+)", l):
        if u not in users: users.append(u)
print(f"\n[*] {len(users)} distinct user_ids in server.log")
hit_ids = {h[0] for h in hits}
print("[*] Interesting log lines (key_rotated, unpublished fingerprints, or mentioning a HIT id):")
for l in log:
    fps = re.findall(r"\b[0-9a-f]{64}\b", l)
    if "key_rotated" in l or any(x not in published for x in fps) or any(i in l for i in hit_ids):
        if "action=invalidate" in l and not any(i in l for i in hit_ids): continue
        print("    " + l)
print("[*] Sample enroll line:", next((l for l in log if "action=enroll" in l), None))

# ---------- 4. vault ----------
man = json.load(open(P("vault_manifest.json")))
nonce = binascii.unhexlify(man["nonce"])
blob = open(P(os.path.basename(man.get("vault_file", "encrypted_vault.bin"))), "rb").read()
print(f"\n[*] vault {len(blob)} bytes, nonce {man['nonce']}")
done = False
for cid, kn, vk in hits:
    if len(vk) != 32: continue
    for aad in [u.encode() for u in users] + [cid.encode(), b"user_id", None]:
        try:
            pt = AESGCM(vk).decrypt(nonce, blob, aad)
        except Exception: continue
        print("\n" + "=" * 70)
        print(f"Q1 victim user_id : {aad.decode() if aad else '(AAD=None)'}")
        print(f"Q2 vault key      : {vk.hex()}")
        print(f"   (recovery id {cid}, unwrapped with {kn})")
        print("=" * 70)
        try: print(json.dumps(json.loads(pt), indent=2))
        except Exception: print(pt.decode(errors="replace"))
        open("vault_decrypted.json", "wb").write(pt)
        done = True; break
    if done: break
if not done: print("[-] vault not opened - check the interesting log lines above for the enrollment format")
